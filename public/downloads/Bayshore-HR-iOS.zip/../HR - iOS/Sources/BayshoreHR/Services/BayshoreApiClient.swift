import Foundation
import UIKit

@MainActor
public final class BayshoreApiClient: ObservableObject {
    public static let shared = BayshoreApiClient()

    @Published public var serverURLString: String {
        didSet {
            UserDefaults.standard.set(serverURLString, forKey: "bayshore_server_url")
        }
    }
    @Published public var currentUser: SessionUser?
    @Published public var isAuthenticated: Bool = false
    @Published public var isBusy: Bool = false
    @Published public var errorMessage: String?

    private let session: URLSession

    private init() {
        let stored = UserDefaults.standard.string(forKey: "bayshore_server_url") ?? "https://bayshore-hr.vercel.app"
        self.serverURLString = stored

        let config = URLSessionConfiguration.default
        config.httpCookieStorage = HTTPCookieStorage.shared
        config.httpCookieAcceptPolicy = .always
        config.timeoutIntervalForRequest = 15.0
        config.timeoutIntervalForResource = 30.0
        self.session = URLSession(configuration: config)
    }

    public var baseURL: URL {
        URL(string: serverURLString.trimmingCharacters(in: .whitespacesAndNewlines))
            ?? URL(string: "https://bayshore-hr.vercel.app")!
    }

    // MARK: - Health Check
    public func checkHealth(urlOverride: String? = nil) async -> ServerHealth {
        let target = urlOverride?.trimmingCharacters(in: .whitespacesAndNewlines) ?? serverURLString
        guard let url = URL(string: "\(target)/api/health") else {
            return ServerHealth(ok: false, reachedServer: false, issueMessage: "Invalid server URL syntax.")
        }
        var req = URLRequest(url: url)
        req.httpMethod = "GET"
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        req.cachePolicy = .reloadIgnoringLocalCacheData

        do {
            let (data, response) = try await session.data(for: req)
            guard let http = response as? HTTPURLResponse else {
                return ServerHealth(ok: false, reachedServer: false, issueMessage: "Non-HTTP response received.")
            }
            if http.statusCode == 200 || http.statusCode == 500 {
                if let decoded = try? JSONDecoder().decode(ServerHealth.self, from: data) {
                    return decoded
                }
            }
            return ServerHealth(
                ok: false,
                reachedServer: true,
                issueMessage: "Server responded with HTTP \(http.statusCode)"
            )
        } catch {
            return ServerHealth(
                ok: false,
                reachedServer: false,
                issueMessage: error.localizedDescription
            )
        }
    }

    // MARK: - Authentication
    public func login(email: String, pass: String) async -> Bool {
        isBusy = true
        errorMessage = nil
        defer { isBusy = false }

        guard let url = URL(string: "\(baseURL)/api/auth/login") else {
            errorMessage = "Invalid login endpoint."
            return false
        }

        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.setValue("application/json", forHTTPHeaderField: "Accept")

        let payload: [String: Any] = ["email": email.trimmingCharacters(in: .whitespacesAndNewlines), "password": pass]
        req.httpBody = try? JSONSerialization.data(withJSONObject: payload)

        do {
            let (data, response) = try await session.data(for: req)
            guard let http = response as? HTTPURLResponse else {
                errorMessage = "Invalid network response."
                return false
            }
            guard http.statusCode == 200 else {
                if let errJson = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                   let msg = errJson["error"] as? String {
                    errorMessage = msg
                } else {
                    errorMessage = "Login failed (HTTP \(http.statusCode))."
                }
                return false
            }

            if let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
               let userObj = root["user"] as? [String: Any] {
                let user = SessionUser(
                    id: userObj["id"] as? String ?? "emp-me",
                    name: userObj["name"] as? String ?? "Team Member",
                    email: userObj["email"] as? String ?? email,
                    role: userObj["role"] as? String ?? "Employee",
                    avatar: userObj["avatar"] as? String,
                    department: userObj["department"] as? String,
                    employeeId: userObj["employeeId"] as? String,
                    isSuperAdmin: (userObj["role"] as? String) == "Super Admin"
                )
                self.currentUser = user
                self.isAuthenticated = true
                return true
            }
            errorMessage = "Missing user profile in response."
            return false
        } catch {
            errorMessage = error.localizedDescription
            return false
        }
    }

    public func logout() async {
        guard let url = URL(string: "\(baseURL)/api/auth/logout") else { return }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        _ = try? await session.data(for: req)
        if let cookies = HTTPCookieStorage.shared.cookies(for: baseURL) {
            for c in cookies { HTTPCookieStorage.shared.deleteCookie(c) }
        }
        self.currentUser = nil
        self.isAuthenticated = false
    }

    // MARK: - Attendance
    public func getAttendance(date: String? = nil) async -> [AttendanceRecord] {
        var query = ""
        if let d = date, !d.isEmpty {
            query = "?date=\(d)"
        }
        guard let url = URL(string: "\(baseURL)/api/attendance\(query)") else { return [] }
        var req = URLRequest(url: url)
        req.httpMethod = "GET"
        req.setValue("application/json", forHTTPHeaderField: "Accept")

        guard let (data, response) = try? await session.data(for: req),
              let http = response as? HTTPURLResponse, http.statusCode == 200 else {
            return []
        }
        if let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
           let recordsArr = root["records"],
           let recordsData = try? JSONSerialization.data(withJSONObject: recordsArr) {
            if let decoded = try? JSONDecoder().decode([AttendanceRecord].self, from: recordsData) {
                return decoded
            }
        }
        return (try? JSONDecoder().decode([AttendanceRecord].self, from: data)) ?? []
    }

    public func clockIn(lat: Double, lng: Double, address: String) async -> Bool {
        isBusy = true
        defer { isBusy = false }
        guard let url = URL(string: "\(baseURL)/api/attendance/clock-in") else { return false }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let payload: [String: Any] = [
            "latitude": lat,
            "longitude": lng,
            "address": address,
            "workModel": "onsite"
        ]
        req.httpBody = try? JSONSerialization.data(withJSONObject: payload)

        guard let (_, response) = try? await session.data(for: req),
              let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
            return false
        }
        return true
    }

    public func clockOut() async -> Bool {
        isBusy = true
        defer { isBusy = false }
        guard let url = URL(string: "\(baseURL)/api/attendance/clock-out") else { return false }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"

        guard let (_, response) = try? await session.data(for: req),
              let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
            return false
        }
        return true
    }

    // MARK: - Departments
    public func getDepartments() async -> [Department] {
        guard let url = URL(string: "\(baseURL)/api/departments") else { return [] }
        var req = URLRequest(url: url)
        req.httpMethod = "GET"
        req.setValue("application/json", forHTTPHeaderField: "Accept")

        guard let (data, response) = try? await session.data(for: req),
              let http = response as? HTTPURLResponse, http.statusCode == 200 else {
            return []
        }
        if let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
           let arr = root["departments"] as? [[String: Any]] {
            return arr.compactMap { d in
                Department(
                    id: d["_id"] as? String ?? d["id"] as? String ?? UUID().uuidString,
                    name: d["name"] as? String ?? "General",
                    head: d["head"] as? String ?? "TBD",
                    headRole: d["headRole"] as? String ?? "Lead",
                    headAvatar: d["headAvatar"] as? String,
                    headcount: d["headcount"] as? Int ?? 0,
                    openPositions: d["openPositions"] as? Int ?? 0,
                    budget: (d["budget"] as? NSNumber)?.doubleValue ?? 0.0,
                    color: d["color"] as? String ?? "orange"
                )
            }
        }
        return []
    }

    public func addDepartment(name: String, head: String, headRole: String, headcount: Int, openPositions: Int, budget: Double) async -> Bool {
        guard let url = URL(string: "\(baseURL)/api/departments") else { return false }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let payload: [String: Any] = [
            "name": name,
            "head": head,
            "headRole": headRole,
            "headcount": headcount,
            "openPositions": openPositions,
            "budget": budget,
            "color": "orange"
        ]
        req.httpBody = try? JSONSerialization.data(withJSONObject: payload)

        guard let (_, response) = try? await session.data(for: req),
              let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
            return false
        }
        return true
    }

    public func updateDepartment(id: String, name: String, head: String, headRole: String, headcount: Int, openPositions: Int, budget: Double) async -> Bool {
        guard let url = URL(string: "\(baseURL)/api/departments/\(id)") else { return false }
        var req = URLRequest(url: url)
        req.httpMethod = "PATCH"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let payload: [String: Any] = [
            "name": name,
            "head": head,
            "headRole": headRole,
            "headcount": headcount,
            "openPositions": openPositions,
            "budget": budget,
            "color": "orange"
        ]
        req.httpBody = try? JSONSerialization.data(withJSONObject: payload)

        guard let (_, response) = try? await session.data(for: req),
              let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
            return false
        }
        return true
    }

    public func deleteDepartment(id: String) async -> Bool {
        guard let url = URL(string: "\(baseURL)/api/departments/\(id)") else { return false }
        var req = URLRequest(url: url)
        req.httpMethod = "DELETE"

        guard let (_, response) = try? await session.data(for: req),
              let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
            return false
        }
        return true
    }

    // MARK: - Employees
    public func getEmployees() async -> [EmployeeItem] {
        guard let url = URL(string: "\(baseURL)/api/employees") else { return [] }
        var req = URLRequest(url: url)
        req.httpMethod = "GET"
        req.setValue("application/json", forHTTPHeaderField: "Accept")

        guard let (data, response) = try? await session.data(for: req),
              let http = response as? HTTPURLResponse, http.statusCode == 200 else {
            return []
        }
        if let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
           let arr = root["employees"] as? [[String: Any]] {
            return arr.compactMap { d in
                EmployeeItem(
                    id: d["_id"] as? String ?? d["id"] as? String ?? UUID().uuidString,
                    name: d["name"] as? String ?? "",
                    email: d["email"] as? String ?? "",
                    role: d["role"] as? String ?? "Staff",
                    department: d["department"] as? String ?? "Engineering",
                    status: d["status"] as? String ?? "Active",
                    salary: (d["salary"] as? NSNumber)?.doubleValue ?? 60000.0,
                    avatar: d["avatar"] as? String,
                    phone: d["phone"] as? String ?? "",
                    location: d["location"] as? String ?? "Gulshan HQ, Dhaka"
                )
            }
        }
        return []
    }

    public func addEmployee(name: String, email: String, role: String, department: String, salary: Double) async -> Bool {
        guard let url = URL(string: "\(baseURL)/api/employees") else { return false }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let cartoonAvatar = "https://api.dicebear.com/9.x/avataaars/svg?seed=\(name.addingPercentEncoding(withAllowedCharacters: .urlHostAllowed) ?? "member")&backgroundColor=b6e3f4,c0aede,d1d4f9,ffd5dc,ffdfbf"

        let payload: [String: Any] = [
            "name": name,
            "email": email,
            "role": role,
            "department": department,
            "salary": salary,
            "location": "Gulshan HQ, Dhaka",
            "avatar": cartoonAvatar
        ]
        req.httpBody = try? JSONSerialization.data(withJSONObject: payload)

        guard let (_, response) = try? await session.data(for: req),
              let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
            return false
        }
        return true
    }

    public func updateEmployee(id: String, name: String, role: String, department: String, salary: Double, status: String) async -> Bool {
        guard let url = URL(string: "\(baseURL)/api/employees/\(id)") else { return false }
        var req = URLRequest(url: url)
        req.httpMethod = "PATCH"
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let payload: [String: Any] = [
            "name": name,
            "role": role,
            "department": department,
            "salary": salary,
            "status": status
        ]
        req.httpBody = try? JSONSerialization.data(withJSONObject: payload)

        guard let (_, response) = try? await session.data(for: req),
              let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
            return false
        }
        return true
    }

    public func deleteEmployee(id: String) async -> Bool {
        guard let url = URL(string: "\(baseURL)/api/employees/\(id)") else { return false }
        var req = URLRequest(url: url)
        req.httpMethod = "DELETE"

        guard let (_, response) = try? await session.data(for: req),
              let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
            return false
        }
        return true
    }
}

