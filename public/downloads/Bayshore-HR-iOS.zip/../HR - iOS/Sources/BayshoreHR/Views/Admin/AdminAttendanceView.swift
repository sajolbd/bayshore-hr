import SwiftUI

public struct AdminAttendanceView: View {
    @ObservedObject var api = BayshoreApiClient.shared

    @State private var records: [AttendanceRecord] = []
    @State private var isLoading: Bool = false
    @State private var filterMode: String = "today" // "today", "all", "custom"
    @State private var selectedDate: Date = Date()
    @State private var searchQuery: String = ""

    public init() {}

    private var todayString: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: Date())
    }

    private var selectedDateString: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: selectedDate)
    }

    private var filteredRecords: [AttendanceRecord] {
        var base = records
        if filterMode == "today" {
            base = base.filter { ($0.dateKey ?? $0.date) == todayString || $0.date == todayString }
        } else if filterMode == "custom" {
            base = base.filter { ($0.dateKey ?? $0.date) == selectedDateString || $0.date == selectedDateString }
        }
        if !searchQuery.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            let q = searchQuery.lowercased()
            base = base.filter {
                $0.employeeName.lowercased().contains(q) ||
                $0.location.lowercased().contains(q) ||
                $0.date.lowercased().contains(q) ||
                $0.department.lowercased().contains(q)
            }
        }
        return base
    }

    public var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // Filter Header
                VStack(spacing: 10) {
                    Picker("Filter", selection: $filterMode) {
                        Text("Today (\(todayString))").tag("today")
                        Text("All Dates").tag("all")
                        Text("Select Date").tag("custom")
                    }
                    .pickerStyle(.segmented)

                    if filterMode == "custom" {
                        DatePicker("Inspect Date", selection: $selectedDate, displayedComponents: .date)
                            .datePickerStyle(.compact)
                            .padding(.horizontal, 4)
                    }

                    TextField("Search employee, department, location...", text: $searchQuery)
                        .padding(8)
                        .background(BayshoreTheme.slate50)
                        .cornerRadius(8)
                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(BayshoreTheme.slate200, lineWidth: 1))
                        .font(.footnote)
                }
                .padding(14)
                .background(Color.white)
                .overlay(Rectangle().frame(height: 1).foregroundColor(BayshoreTheme.slate200), alignment: .bottom)

                if isLoading {
                    Spacer()
                    ProgressView("Loading attendance...")
                    Spacer()
                } else if filteredRecords.isEmpty {
                    Spacer()
                    Text(filterMode == "today" ? "No team punches recorded today." : "No attendance logs found for this date.")
                        .font(.footnote)
                        .foregroundColor(BayshoreTheme.slate500)
                    Spacer()
                } else {
                    List {
                        ForEach(filteredRecords) { rec in
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(rec.employeeName)
                                            .font(.subheadline)
                                            .fontWeight(.bold)
                                        Text("\(rec.role) • \(rec.department)")
                                            .font(.caption2)
                                            .foregroundColor(BayshoreTheme.slate500)
                                    }
                                    Spacer()
                                    StatusBadgeView(status: rec.status)
                                }

                                HStack(spacing: 16) {
                                    HStack(spacing: 4) {
                                        Image(systemName: "arrow.down.right.circle")
                                            .foregroundColor(BayshoreTheme.emerald600)
                                        Text("In: \(rec.checkIn)")
                                            .font(.caption)
                                    }
                                    if let out = rec.checkOut {
                                        HStack(spacing: 4) {
                                            Image(systemName: "arrow.up.left.circle")
                                                .foregroundColor(BayshoreTheme.slate700)
                                            Text("Out: \(out)")
                                                .font(.caption)
                                        }
                                    }
                                    Spacer()
                                    Text(rec.workHours)
                                        .font(.caption)
                                        .fontWeight(.semibold)
                                }

                                HStack(spacing: 4) {
                                    Image(systemName: "mappin.circle")
                                        .foregroundColor(BayshoreTheme.orange)
                                    Text(rec.location)
                                        .font(.caption2)
                                        .foregroundColor(BayshoreTheme.slate500)
                                }
                            }
                            .padding(.vertical, 4)
                        }
                    }
                    .listStyle(.plain)
                }
            }
            .navigationTitle("Attendance Monitor")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .primaryAction) {
                    Button { loadAttendance() } label: { Image(systemName: "arrow.clockwise") }
                }
            }
            .onAppear { loadAttendance() }
        }
    }

    private func loadAttendance() {
        Task {
            isLoading = true
            records = await api.getAttendance()
            isLoading = false
        }
    }
}

