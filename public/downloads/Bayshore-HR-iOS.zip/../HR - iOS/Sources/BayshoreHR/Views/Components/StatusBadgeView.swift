import SwiftUI

public struct StatusBadgeView: View {
    public let status: String

    public init(status: String) {
        self.status = status
    }

    private var colors: (bg: Color, text: Color) {
        switch status.lowercased() {
        case "active", "present", "approved":
            return (BayshoreTheme.emerald50, BayshoreTheme.emerald600)
        case "pending", "invited", "late":
            return (BayshoreTheme.amber50, BayshoreTheme.amber600)
        case "rejected", "absent", "leave", "on leave":
            return (BayshoreTheme.red50, BayshoreTheme.red600)
        default:
            return (BayshoreTheme.slate100, BayshoreTheme.slate700)
        }
    }

    public var body: some View {
        Text(status)
            .font(.system(size: 11, weight: .bold))
            .foregroundColor(colors.text)
            .padding(.horizontal, 8)
            .padding(.vertical, 3)
            .background(colors.bg)
            .clipShape(Capsule())
    }
}

public struct KpiCardView: View {
    public let title: String
    public let value: String
    public let subtitle: String?
    public let iconName: String
    public let color: Color

    public init(
        title: String,
        value: String,
        subtitle: String? = nil,
        iconName: String = "chart.bar.fill",
        color: Color = BayshoreTheme.orange
    ) {
        self.title = title
        self.value = value
        self.subtitle = subtitle
        self.iconName = iconName
        self.color = color
    }

    public var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text(title)
                    .font(.caption)
                    .foregroundColor(BayshoreTheme.slate500)
                Spacer()
                Image(systemName: iconName)
                    .font(.system(size: 13, weight: .semibold))
                    .foregroundColor(color)
            }
            Text(value)
                .font(.title3)
                .fontWeight(.bold)
                .foregroundColor(BayshoreTheme.slate900)
            if let sub = subtitle {
                Text(sub)
                    .font(.caption2)
                    .foregroundColor(BayshoreTheme.slate500)
            }
        }
        .bayshoreCard()
    }
}

