import SwiftUI

public struct AdminDepartmentsView: View {
    @ObservedObject var api = BayshoreApiClient.shared

    @State private var departments: [Department] = []
    @State private var employees: [EmployeeItem] = []
    @State private var isLoading: Bool = false
    @State private var showAddSheet: Bool = false
    @State private var editingDepartment: Department?
    @State private var rosterDepartment: Department?

    // Add Form
    @State private var newName: String = ""
    @State private var newHead: String = ""
    @State private var newHeadRole: String = "Department Lead"
    @State private var newHeadcount: String = "5"
    @State private var newOpenPositions: String = "2"
    @State private var newBudget: String = "450000"

    public init() {}

    public var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 12) {
                    if isLoading {
                        ProgressView("Loading departments...")
                            .padding(.top, 40)
                    } else if departments.isEmpty {
                        Text("No departments found.")
                            .foregroundColor(BayshoreTheme.slate500)
                            .padding(.top, 40)
                    } else {
                        ForEach(departments) { dept in
                            let deptEmps = employees.filter { $0.department.caseInsensitiveCompare(dept.name) == .orderedSame }
                            VStack(alignment: .leading, spacing: 10) {
                                HStack {
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(dept.name)
                                            .font(.headline)
                                            .foregroundColor(BayshoreTheme.slate900)
                                        Text("Lead: \(dept.head) (\(dept.headRole))")
                                            .font(.caption)
                                            .foregroundColor(BayshoreTheme.slate500)
                                    }
                                    Spacer()
                                }

                                HStack(spacing: 8) {
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text("Headcount")
                                            .font(.caption2)
                                            .foregroundColor(BayshoreTheme.slate500)
                                        Text("\(deptEmps.isEmpty ? dept.headcount : deptEmps.count)")
                                            .font(.subheadline)
                                            .fontWeight(.bold)
                                    }
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .padding(8)
                                    .background(BayshoreTheme.slate100)
                                    .cornerRadius(8)

                                    VStack(alignment: .leading, spacing: 2) {
                                        Text("Open Roles")
                                            .font(.caption2)
                                            .foregroundColor(BayshoreTheme.emerald600)
                                        Text("\(dept.openPositions)")
                                            .font(.subheadline)
                                            .fontWeight(.bold)
                                            .foregroundColor(BayshoreTheme.emerald600)
                                    }
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .padding(8)
                                    .background(BayshoreTheme.emerald50)
                                    .cornerRadius(8)

                                    VStack(alignment: .leading, spacing: 2) {
                                        Text("Monthly Budget")
                                            .font(.caption2)
                                            .foregroundColor(BayshoreTheme.amber600)
                                        Text("৳\(Int(dept.budget))")
                                            .font(.subheadline)
                                            .fontWeight(.bold)
                                            .foregroundColor(BayshoreTheme.slate900)
                                    }
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .padding(8)
                                    .background(BayshoreTheme.amber50)
                                    .cornerRadius(8)
                                }

                                HStack(spacing: 8) {
                                    Button {
                                        rosterDepartment = dept
                                    } label: {
                                        HStack(spacing: 4) {
                                            Image(systemName: "person.2")
                                            Text("Roster (\(deptEmps.count))")
                                        }
                                        .font(.caption)
                                        .padding(.horizontal, 10)
                                        .padding(.vertical, 6)
                                        .background(BayshoreTheme.slate100)
                                        .foregroundColor(BayshoreTheme.slate700)
                                        .cornerRadius(8)
                                    }

                                    Button {
                                        editingDepartment = dept
                                    } label: {
                                        HStack(spacing: 4) {
                                            Image(systemName: "pencil")
                                            Text("Edit")
                                        }
                                        .font(.caption)
                                        .padding(.horizontal, 10)
                                        .padding(.vertical, 6)
                                        .background(BayshoreTheme.slate100)
                                        .foregroundColor(BayshoreTheme.slate700)
                                        .cornerRadius(8)
                                    }

                                    Spacer()
                                }
                            }
                            .bayshoreCard()
                        }
                    }
                }
                .padding(16)
            }
            .navigationTitle("Departments (\(departments.count))")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .primaryAction) {
                    Button {
                        showAddSheet = true
                    } label: {
                        Image(systemName: "plus")
                    }
                }
            }
            .onAppear { loadData() }
            .sheet(isPresented: $showAddSheet) {
                addDepartmentSheet
            }
            .sheet(item: $editingDepartment) { dept in
                EditDepartmentSheetView(dept: dept) {
                    editingDepartment = nil
                    loadData()
                }
            }
            .sheet(item: $rosterDepartment) { dept in
                let deptEmps = employees.filter { $0.department.caseInsensitiveCompare(dept.name) == .orderedSame }
                DepartmentRosterSheetView(department: dept, employees: deptEmps)
            }
        }
    }

    private var addDepartmentSheet: some View {
        NavigationStack {
            Form {
                Section("Department Information") {
                    TextField("Department Name", text: $newName)
                    TextField("Head / Lead", text: $newHead)
                    TextField("Title", text: $newHeadRole)
                    TextField("Headcount", text: $newHeadcount)
                        .keyboardType(.numberPad)
                    TextField("Open Roles", text: $newOpenPositions)
                        .keyboardType(.numberPad)
                    TextField("Monthly Budget (BDT)", text: $newBudget)
                        .keyboardType(.numberPad)
                }

                Section {
                    Button("Create Department") {
                        Task {
                            let hc = Int(newHeadcount) ?? 0
                            let op = Int(newOpenPositions) ?? 0
                            let bg = Double(newBudget) ?? 0.0
                            let ok = await api.addDepartment(
                                name: newName,
                                head: newHead,
                                headRole: newHeadRole,
                                headcount: hc,
                                openPositions: op,
                                budget: bg
                            )
                            if ok {
                                showAddSheet = false
                                newName = ""
                                newHead = ""
                                loadData()
                            }
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(BayshoreTheme.orange)
                    .disabled(newName.isEmpty || newHead.isEmpty)
                }
            }
            .navigationTitle("Add Department")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { showAddSheet = false }
                }
            }
        }
    }

    private func loadData() {
        Task {
            isLoading = true
            departments = await api.getDepartments()
            employees = await api.getEmployees()
            isLoading = false
        }
    }
}

public struct EditDepartmentSheetView: View {
    @ObservedObject var api = BayshoreApiClient.shared
    public let dept: Department
    public let onDone: () -> Void

    @State private var name: String
    @State private var head: String
    @State private var headRole: String
    @State private var headcount: String
    @State private var openPositions: String
    @State private var budget: String

    public init(dept: Department, onDone: @escaping () -> Void) {
        self.dept = dept
        self.onDone = onDone
        _name = State(initialValue: dept.name)
        _head = State(initialValue: dept.head)
        _headRole = State(initialValue: dept.headRole)
        _headcount = State(initialValue: "\(dept.headcount)")
        _openPositions = State(initialValue: "\(dept.openPositions)")
        _budget = State(initialValue: String(format: "%.0f", dept.budget))
    }

    public var body: some View {
        NavigationStack {
            Form {
                Section("Edit Department") {
                    TextField("Department Name", text: $name)
                    TextField("Head / Lead", text: $head)
                    TextField("Title", text: $headRole)
                    TextField("Headcount", text: $headcount)
                        .keyboardType(.numberPad)
                    TextField("Open Roles", text: $openPositions)
                        .keyboardType(.numberPad)
                    TextField("Monthly Budget (BDT)", text: $budget)
                        .keyboardType(.numberPad)
                }

                Section {
                    Button("Save Changes") {
                        Task {
                            let hc = Int(headcount) ?? dept.headcount
                            let op = Int(openPositions) ?? dept.openPositions
                            let bg = Double(budget) ?? dept.budget
                            let ok = await api.updateDepartment(
                                id: dept.id,
                                name: name,
                                head: head,
                                headRole: headRole,
                                headcount: hc,
                                openPositions: op,
                                budget: bg
                            )
                            if ok { onDone() }
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(BayshoreTheme.orange)
                }
            }
            .navigationTitle("Edit Department")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { onDone() }
                }
            }
        }
    }
}

public struct DepartmentRosterSheetView: View {
    public let department: Department
    public let employees: [EmployeeItem]
    @Environment(\.dismiss) private var dismiss

    public var body: some View {
        NavigationStack {
            List {
                if employees.isEmpty {
                    Text("No employees currently assigned to this department.")
                        .font(.footnote)
                        .foregroundColor(BayshoreTheme.slate500)
                } else {
                    ForEach(employees) { emp in
                        HStack {
                            VStack(alignment: .leading, spacing: 2) {
                                Text(emp.name)
                                    .font(.subheadline)
                                    .fontWeight(.bold)
                                Text(emp.role)
                                    .font(.caption)
                                    .foregroundColor(BayshoreTheme.slate500)
                            }
                            Spacer()
                            StatusBadgeView(status: emp.status)
                        }
                    }
                }
            }
            .navigationTitle("\(department.name) Roster")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Close") { dismiss() }
                }
            }
        }
    }
}

