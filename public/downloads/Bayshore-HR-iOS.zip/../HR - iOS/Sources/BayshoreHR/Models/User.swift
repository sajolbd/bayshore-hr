import Foundation

public struct SessionUser: Identifiable, Codable, Equatable {
    public let id: String
    public let name: String
    public let email: String
    public let role: String
    public let avatar: String?
    public let department: String?
    public let employeeId: String?
    public let isSuperAdmin: Bool

    public init(
        id: String,
        name: String,
        email: String,
        role: String,
        avatar: String? = nil,
        department: String? = nil,
        employeeId: String? = nil,
        isSuperAdmin: Bool = false
    ) {
        self.id = id
        self.name = name
        self.email = email
        self.role = role
        self.avatar = avatar
        self.department = department
        self.employeeId = employeeId
        self.isSuperAdmin = isSuperAdmin
    }
}

public struct EmployeeProfile: Identifiable, Codable {
    public let id: String
    public var name: String
    public var email: String
    public var avatar: String?
    public var role: String
    public var department: String
    public var phone: String
    public var location: String
    public var joinDate: String
    public var reportingManager: String
    public var reportingManagerRole: String
    public var bloodGroup: String
    public var nidOrPassport: String
    public var dateOfBirth: String
    public var emergencyContact: EmergencyContact

    public init(
        id: String,
        name: String,
        email: String,
        avatar: String? = nil,
        role: String = "Staff Member",
        department: String = "Engineering",
        phone: String = "",
        location: String = "Gulshan HQ, Dhaka",
        joinDate: String = "",
        reportingManager: String = "Shamim Ahsan",
        reportingManagerRole: String = "Super Admin",
        bloodGroup: String = "O+",
        nidOrPassport: String = "Verified",
        dateOfBirth: String = "",
        emergencyContact: EmergencyContact = .init()
    ) {
        self.id = id
        self.name = name
        self.email = email
        self.avatar = avatar
        self.role = role
        self.department = department
        self.phone = phone
        self.location = location
        self.joinDate = joinDate
        self.reportingManager = reportingManager
        self.reportingManagerRole = reportingManagerRole
        self.bloodGroup = bloodGroup
        self.nidOrPassport = nidOrPassport
        self.dateOfBirth = dateOfBirth
        self.emergencyContact = emergencyContact
    }
}

public struct EmergencyContact: Codable {
    public var name: String
    public var relationship: String
    public var phone: String

    public init(name: String = "", relationship: String = "", phone: String = "") {
        self.name = name
        self.relationship = relationship
        self.phone = phone
    }
}

