import Foundation

public struct AttendanceRecord: Identifiable, Codable, Equatable {
    public let id: String
    public let employeeId: String
    public let employeeName: String
    public let employeeEmail: String
    public let avatar: String?
    public let department: String
    public let role: String
    public let checkIn: String
    public let checkOut: String?
    public let status: String
    public let workHours: String
    public let location: String
    public let date: String
    public let dateKey: String?
    public let geo: AttendanceGeo?

    public init(
        id: String,
        employeeId: String,
        employeeName: String,
        employeeEmail: String,
        avatar: String? = nil,
        department: String = "Engineering",
        role: String = "Staff",
        checkIn: String,
        checkOut: String? = nil,
        status: String = "Present",
        workHours: String = "0h 0m",
        location: String = "Gulshan HQ, Dhaka",
        date: String = "",
        dateKey: String? = nil,
        geo: AttendanceGeo? = nil
    ) {
        self.id = id
        self.employeeId = employeeId
        self.employeeName = employeeName
        self.employeeEmail = employeeEmail
        self.avatar = avatar
        self.department = department
        self.role = role
        self.checkIn = checkIn
        self.checkOut = checkOut
        self.status = status
        self.workHours = workHours
        self.location = location
        self.date = date
        self.dateKey = dateKey
        self.geo = geo
    }
}

public struct AttendanceGeo: Codable, Equatable {
    public let latitude: Double?
    public let longitude: Double?
    public let accuracy: Double?
    public let address: String?
    public let geofenceStatus: String?
    public let distanceFromHQ: Double?
    public let checkInType: String?
    public let timestamp: String?

    public init(
        latitude: Double? = nil,
        longitude: Double? = nil,
        accuracy: Double? = nil,
        address: String? = nil,
        geofenceStatus: String? = nil,
        distanceFromHQ: Double? = nil,
        checkInType: String? = "Time Clock",
        timestamp: String? = nil
    ) {
        self.latitude = latitude
        self.longitude = longitude
        self.accuracy = accuracy
        self.address = address
        self.geofenceStatus = geofenceStatus
        self.distanceFromHQ = distanceFromHQ
        self.checkInType = checkInType
        self.timestamp = timestamp
    }
}

