import XCTest
@testable import BayshoreHR

final class BayshoreHRTests: XCTestCase {
    func testAppInitializes() {
        XCTAssertNotNil(BayshoreApiClient.shared)
    }
}
