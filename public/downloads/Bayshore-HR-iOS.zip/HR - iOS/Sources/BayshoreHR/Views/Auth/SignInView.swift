import SwiftUI

public struct SignInView: View {
    @ObservedObject var api = BayshoreApiClient.shared

    @State private var email: String = ""
    @State private var password: String = ""
    @State private var showServerSheet: Bool = false
    @State private var showPassword: Bool = false

    public init() {}

    public var body: some View {
        ScrollView {
            VStack(spacing: 24) {
                Spacer(minLength: 30)

                // Logo & Header
                VStack(spacing: 12) {
                    BayshoreLogoView(size: 72)
                    Text("Bayshore HR")
                        .font(.system(size: 26, weight: .bold))
                        .foregroundColor(BayshoreTheme.slate900)
                    Text("Bayshore Communication • Gulshan HQ")
                        .font(.footnote)
                        .foregroundColor(BayshoreTheme.slate500)
                }

                // Login Card
                VStack(spacing: 16) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Work Email")
                            .font(.caption)
                            .fontWeight(.medium)
                            .foregroundColor(BayshoreTheme.slate700)
                        TextField("name@bayshore.com", text: $email)
                            .padding(12)
                            .background(BayshoreTheme.slate50)
                            .cornerRadius(10)
                            .overlay(RoundedRectangle(cornerRadius: 10).stroke(BayshoreTheme.slate200, lineWidth: 1))
                            .autocorrectionDisabled()
                            .textInputAutocapitalization(.never)
                            .keyboardType(.emailAddress)
                    }

                    VStack(alignment: .leading, spacing: 6) {
                        Text("Password")
                            .font(.caption)
                            .fontWeight(.medium)
                            .foregroundColor(BayshoreTheme.slate700)
                        HStack {
                            if showPassword {
                                TextField("Enter your password", text: $password)
                            } else {
                                SecureField("Enter your password", text: $password)
                            }
                            Button {
                                showPassword.toggle()
                            } label: {
                                Image(systemName: showPassword ? "eye.slash" : "eye")
                                    .foregroundColor(BayshoreTheme.slate500)
                            }
                        }
                        .padding(12)
                        .background(BayshoreTheme.slate50)
                        .cornerRadius(10)
                        .overlay(RoundedRectangle(cornerRadius: 10).stroke(BayshoreTheme.slate200, lineWidth: 1))
                    }

                    if let err = api.errorMessage {
                        Text(err)
                            .font(.caption)
                            .foregroundColor(BayshoreTheme.red600)
                            .multilineTextAlignment(.center)
                    }

                    Button {
                        Task {
                            _ = await api.login(email: email, pass: password)
                        }
                    } label: {
                        HStack {
                            if api.isBusy {
                                ProgressView()
                                    .tint(.white)
                                    .padding(.trailing, 6)
                            }
                            Text("Sign In to Workspace")
                                .fontWeight(.bold)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(14)
                        .background(BayshoreTheme.orange)
                        .foregroundColor(.white)
                        .cornerRadius(12)
                    }
                    .disabled(api.isBusy || email.isEmpty || password.isEmpty)
                }
                .bayshoreCard()
                .padding(.horizontal, 20)

                // Quick Demo Fill
                VStack(spacing: 8) {
                    Text("Quick Test Accounts")
                        .font(.caption2)
                        .foregroundColor(BayshoreTheme.slate500)
                    HStack(spacing: 12) {
                        Button("Super Admin") {
                            email = "shamim@bayshore.com"
                            password = "password123"
                        }
                        .font(.caption)
                        .buttonStyle(.bordered)

                        Button("Employee") {
                            email = "elena.r@bayshore.com"
                            password = "password123"
                        }
                        .font(.caption)
                        .buttonStyle(.bordered)
                    }
                }

                // Server Settings Link
                Button {
                    showServerSheet = true
                } label: {
                    HStack(spacing: 6) {
                        Image(systemName: "gearshape")
                        Text("Server & Diagnostics")
                    }
                    .font(.footnote)
                    .foregroundColor(BayshoreTheme.slate500)
                }

                Spacer(minLength: 20)
            }
        }
        .background(BayshoreTheme.slate50.ignoresSafeArea())
        .sheet(isPresented: $showServerSheet) {
            ServerConfigSheet()
        }
    }
}

