import SwiftUI

public struct SignInView: View {
    @ObservedObject var api = BayshoreApiClient.shared

    @State private var email: String = ""
    @State private var password: String = ""
    @State private var showServerSheet: Bool = false
    @State private var showPassword: Bool = false
    @State private var showForgotSheet: Bool = false
    @State private var forgotEmail: String = ""
    @State private var forgotMessage: String = ""
    @State private var forgotIsSending: Bool = false

    public init() {}

    public var body: some View {
        ScrollView {
            VStack(spacing: 24) {
                Spacer(minLength: 30)

                // Logo & Header
                VStack(spacing: 12) {
                    BayshoreLogoView(size: 72)
                    Text("Bayshore HR")
                        .font(.system(size: 26, weight: .bold))
                        .foregroundColor(BayshoreTheme.slate900)
                    Text("Bayshore Communication • Abtab Nagar HQ")
                        .font(.footnote)
                        .foregroundColor(BayshoreTheme.slate500)
                }

                // Login Card
                VStack(spacing: 16) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Work Email")
                            .font(.caption)
                            .fontWeight(.medium)
                            .foregroundColor(BayshoreTheme.slate700)
                        TextField("name@bayshore.com", text: $email)
                            .padding(12)
                            .background(BayshoreTheme.slate50)
                            .cornerRadius(10)
                            .overlay(RoundedRectangle(cornerRadius: 10).stroke(BayshoreTheme.slate200, lineWidth: 1))
                            .autocorrectionDisabled()
                            .textInputAutocapitalization(.never)
                            .keyboardType(.emailAddress)
                    }

                    VStack(alignment: .leading, spacing: 6) {
                        Text("Password")
                            .font(.caption)
                            .fontWeight(.medium)
                            .foregroundColor(BayshoreTheme.slate700)
                        HStack {
                            if showPassword {
                                TextField("Enter your password", text: $password)
                            } else {
                                SecureField("Enter your password", text: $password)
                            }
                            Button {
                                showPassword.toggle()
                            } label: {
                                Image(systemName: showPassword ? "eye.slash" : "eye")
                                    .foregroundColor(BayshoreTheme.slate500)
                            }
                        }
                        .padding(12)
                        .background(BayshoreTheme.slate50)
                        .cornerRadius(10)
                        .overlay(RoundedRectangle(cornerRadius: 10).stroke(BayshoreTheme.slate200, lineWidth: 1))

                        HStack {
                            Spacer()
                            Button("Forgot Password?") {
                                forgotEmail = email
                                forgotMessage = ""
                                showForgotSheet = true
                            }
                            .font(.caption)
                            .foregroundColor(BayshoreTheme.orange)
                        }
                    }

                    if let err = api.errorMessage {
                        Text(err)
                            .font(.caption)
                            .foregroundColor(BayshoreTheme.red600)
                            .multilineTextAlignment(.center)
                    }

                    Button {
                        Task {
                            _ = await api.login(email: email, pass: password)
                        }
                    } label: {
                        HStack {
                            if api.isBusy {
                                ProgressView()
                                    .tint(.white)
                                    .padding(.trailing, 6)
                            }
                            Text("Sign In to Workspace")
                                .fontWeight(.bold)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(14)
                        .background(BayshoreTheme.orange)
                        .foregroundColor(.white)
                        .cornerRadius(12)
                    }
                    .disabled(api.isBusy || email.isEmpty || password.isEmpty)
                }
                .bayshoreCard()
                .padding(.horizontal, 20)

                // Quick Demo Fill
                VStack(spacing: 8) {
                    Text("Quick Test Accounts")
                        .font(.caption2)
                        .foregroundColor(BayshoreTheme.slate500)
                    HStack(spacing: 12) {
                        Button("Super Admin") {
                            email = "shamim@bayshore.com"
                            password = "password123"
                        }
                        .font(.caption)
                        .buttonStyle(.bordered)

                        Button("Employee") {
                            email = "elena.r@bayshore.com"
                            password = "password123"
                        }
                        .font(.caption)
                        .buttonStyle(.bordered)
                    }
                }

                // Server Settings Link
                Button {
                    showServerSheet = true
                } label: {
                    HStack(spacing: 6) {
                        Image(systemName: "gearshape")
                        Text("Server & Diagnostics")
                    }
                    .font(.footnote)
                    .foregroundColor(BayshoreTheme.slate500)
                }

                Spacer(minLength: 20)
            }
        }
        .background(BayshoreTheme.slate50.ignoresSafeArea())
        .sheet(isPresented: $showServerSheet) {
            ServerConfigSheet()
        }
        .sheet(isPresented: $showForgotSheet) {
            NavigationStack {
                VStack(spacing: 20) {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Reset Account Password")
                            .font(.headline)
                            .foregroundColor(BayshoreTheme.slate900)
                        Text("Enter your registered corporate email to receive a secure password reset link valid for 1 hour.")
                            .font(.caption)
                            .foregroundColor(BayshoreTheme.slate500)
                    }

                    TextField("name@bayshore.com", text: $forgotEmail)
                        .padding(12)
                        .background(BayshoreTheme.slate50)
                        .cornerRadius(10)
                        .overlay(RoundedRectangle(cornerRadius: 10).stroke(BayshoreTheme.slate200, lineWidth: 1))
                        .autocorrectionDisabled()
                        .textInputAutocapitalization(.never)
                        .keyboardType(.emailAddress)

                    if !forgotMessage.isEmpty {
                        Text(forgotMessage)
                            .font(.caption)
                            .foregroundColor(BayshoreTheme.emerald600)
                            .multilineTextAlignment(.center)
                            .padding(10)
                            .background(BayshoreTheme.emerald50)
                            .cornerRadius(8)
                    }

                    Button {
                        Task {
                            forgotIsSending = true
                            let (_, msg) = await api.forgotPassword(email: forgotEmail)
                            forgotMessage = msg
                            forgotIsSending = false
                        }
                    } label: {
                        HStack {
                            if forgotIsSending {
                                ProgressView().tint(.white).padding(.trailing, 6)
                            }
                            Text("Send Reset Link")
                                .fontWeight(.bold)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(14)
                        .background(BayshoreTheme.orange)
                        .foregroundColor(.white)
                        .cornerRadius(12)
                    }
                    .disabled(forgotIsSending || forgotEmail.isEmpty)

                    Spacer()
                }
                .padding(20)
                .navigationTitle("Forgot Password")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("Close") { showForgotSheet = false }
                    }
                }
            }
            .presentationDetents([.medium])
        }
    }
}

