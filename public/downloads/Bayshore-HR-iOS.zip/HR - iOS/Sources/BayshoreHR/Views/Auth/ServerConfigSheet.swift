import SwiftUI

public struct ServerConfigSheet: View {
    @ObservedObject var api = BayshoreApiClient.shared
    @Environment(\.dismiss) private var dismiss

    @State private var urlInput: String = ""
    @State private var isTesting: Bool = false
    @State private var healthResult: ServerHealth?

    public init() {}

    public var body: some View {
        NavigationStack {
            Form {
                Section {
                    Text("Connect to your live Bayshore HR deployment or a local Wi-Fi development server.")
                        .font(.caption)
                        .foregroundColor(BayshoreTheme.slate500)

                    TextField("Backend URL", text: $urlInput)
                        .autocorrectionDisabled()
                        .textInputAutocapitalization(.never)

                    HStack(spacing: 8) {
                        Button("Vercel Prod") {
                            urlInput = "https://bayshore-hr.vercel.app"
                        }
                        .buttonStyle(.bordered)
                        .font(.caption)

                        Button("Local Wi-Fi") {
                            urlInput = "http://192.168.68.110:3000"
                        }
                        .buttonStyle(.bordered)
                        .font(.caption)
                    }
                } header: {
                    Text("Server Configuration")
                }

                Section {
                    Button {
                        Task {
                            isTesting = true
                            healthResult = await api.checkHealth(urlOverride: urlInput)
                            isTesting = false
                        }
                    } label: {
                        HStack {
                            if isTesting {
                                ProgressView()
                                    .padding(.trailing, 6)
                                Text("Testing Connection...")
                            } else {
                                Image(systemName: "network")
                                Text("Test Server Connection")
                            }
                        }
                        .fontWeight(.semibold)
                    }
                    .disabled(isTesting || urlInput.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)

                    if let health = healthResult {
                        VStack(alignment: .leading, spacing: 6) {
                            HStack {
                                Circle()
                                    .fill(health.ok ? Color.green : Color.red)
                                    .frame(width: 8, height: 8)
                                Text(health.ok ? "Server Healthy (\(health.databaseName ?? "bayshore_hr"))" : (health.reachedServer ? "Configuration Issue" : "Cannot Reach Server"))
                                    .font(.subheadline)
                                    .fontWeight(.bold)
                                    .foregroundColor(health.ok ? BayshoreTheme.emerald600 : BayshoreTheme.red600)
                            }
                            if health.reachedServer {
                                Text("MongoDB: \(health.databaseConnected ? "Connected" : "Disconnected") | JWT: \(health.jwtSecretConfigured ? "Ready" : "Missing") | SMTP: \(health.smtpConfigured ? "Ready (\(health.smtpSource))" : "Not Set")")
                                    .font(.caption2)
                                    .foregroundColor(BayshoreTheme.slate700)
                            }
                            if let msg = health.issueMessage, !msg.isEmpty {
                                Text(msg)
                                    .font(.caption2)
                                    .foregroundColor(BayshoreTheme.red600)
                            }
                        }
                        .padding(.vertical, 4)
                    }
                }

                Section {
                    Button("Save Server URL") {
                        api.serverURLString = urlInput.trimmingCharacters(in: .whitespacesAndNewlines)
                        dismiss()
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(BayshoreTheme.orange)
                    .frame(maxWidth: .infinity)
                }
            }
            .navigationTitle("Server & Diagnostics")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Close") { dismiss() }
                }
            }
            .onAppear {
                urlInput = api.serverURLString
            }
        }
    }
}

