import SwiftUI

public struct EmployeeAttendanceView: View {
    @ObservedObject var api = BayshoreApiClient.shared

    @State private var records: [AttendanceRecord] = []
    @State private var isLoading: Bool = false
    @State private var filterMode: String = "today" // "today", "all", "custom"
    @State private var selectedDate: Date = Date()
    @State private var searchQuery: String = ""
    @State private var showMonthlyReport: Bool = false

    public init() {}

    private var todayString: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: Date())
    }

    private var selectedDateString: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter.string(from: selectedDate)
    }

    private var filteredRecords: [AttendanceRecord] {
        var base = records
        if filterMode == "today" {
            base = base.filter { ($0.dateKey ?? $0.date) == todayString || $0.date == todayString }
        } else if filterMode == "custom" {
            base = base.filter { ($0.dateKey ?? $0.date) == selectedDateString || $0.date == selectedDateString }
        }
        if !searchQuery.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            let q = searchQuery.lowercased()
            base = base.filter {
                $0.location.lowercased().contains(q) ||
                $0.checkIn.lowercased().contains(q) ||
                $0.date.lowercased().contains(q)
            }
        }
        return base
    }

    public var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // Filter Header
                VStack(spacing: 10) {
                    Picker("Filter", selection: $filterMode) {
                        Text("Today (\(todayString))").tag("today")
                        Text("All Dates").tag("all")
                        Text("Select Date").tag("custom")
                    }
                    .pickerStyle(.segmented)

                    if filterMode == "custom" {
                        DatePicker("Inspect Date", selection: $selectedDate, displayedComponents: .date)
                            .datePickerStyle(.compact)
                            .padding(.horizontal, 4)
                    }

                    TextField("Search punch, date, or location...", text: $searchQuery)
                        .padding(8)
                        .background(BayshoreTheme.slate50)
                        .cornerRadius(8)
                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(BayshoreTheme.slate200, lineWidth: 1))
                        .font(.footnote)
                }
                .padding(14)
                .background(Color.white)
                .overlay(Rectangle().frame(height: 1).foregroundColor(BayshoreTheme.slate200), alignment: .bottom)

                // List of Records
                if isLoading {
                    Spacer()
                    ProgressView("Loading attendance logs...")
                    Spacer()
                } else if filteredRecords.isEmpty {
                    Spacer()
                    VStack(spacing: 8) {
                        Image(systemName: "clock.badge.questionmark")
                            .font(.system(size: 36))
                            .foregroundColor(BayshoreTheme.slate500)
                        Text(filterMode == "today" ? "No attendance punches recorded today." : "No matching records found.")
                            .font(.footnote)
                            .foregroundColor(BayshoreTheme.slate500)
                    }
                    Spacer()
                } else {
                    List {
                        ForEach(filteredRecords) { rec in
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    Text(rec.date.isEmpty ? todayString : rec.date)
                                        .font(.subheadline)
                                        .fontWeight(.bold)
                                        .foregroundColor(BayshoreTheme.slate900)
                                    Spacer()
                                    StatusBadgeView(status: rec.status)
                                }

                                HStack(spacing: 12) {
                                    if rec.isLateCheckIn {
                                        let lateSuffix = (rec.lateMinutes ?? 0) > 0 ? " (+\(rec.lateMinutes ?? 0)m)" : " (LATE)"
                                        HStack(spacing: 4) {
                                            Image(systemName: "exclamationmark.circle.fill")
                                                .foregroundColor(BayshoreTheme.red600)
                                            Text("In: \(rec.checkIn)\(lateSuffix)")
                                                .font(.caption)
                                                .fontWeight(.heavy)
                                                .foregroundColor(BayshoreTheme.red600)
                                        }
                                        .padding(.horizontal, 8)
                                        .padding(.vertical, 3)
                                        .background(BayshoreTheme.red50)
                                        .overlay(
                                            RoundedRectangle(cornerRadius: 6)
                                                .stroke(BayshoreTheme.red600.opacity(0.45), lineWidth: 1)
                                        )
                                        .cornerRadius(6)
                                    } else {
                                        HStack(spacing: 4) {
                                            Image(systemName: "arrow.down.right.circle")
                                                .foregroundColor(BayshoreTheme.emerald600)
                                            Text("In: \(rec.checkIn)")
                                                .font(.caption)
                                        }
                                    }
                                    if let out = rec.checkOut {
                                        HStack(spacing: 4) {
                                            Image(systemName: "arrow.up.left.circle")
                                                .foregroundColor(BayshoreTheme.slate700)
                                            Text("Out: \(out)")
                                                .font(.caption)
                                        }
                                    }
                                    Spacer()
                                    Text(rec.workHours)
                                        .font(.caption)
                                        .fontWeight(.semibold)
                                        .foregroundColor(BayshoreTheme.slate700)
                                }

                                if let schIn = rec.scheduledInTime, !schIn.isEmpty {
                                    Text("Shift: \(formatShiftTime12h(schIn)) – \(formatShiftTime12h(rec.scheduledOutTime, fallback: "06:00 PM"))")
                                        .font(.caption2)
                                        .foregroundColor(BayshoreTheme.slate500)
                                }

                                HStack(spacing: 4) {
                                    Image(systemName: "mappin.circle")
                                        .foregroundColor(BayshoreTheme.orange)
                                    Text(rec.location)
                                        .font(.caption2)
                                        .foregroundColor(BayshoreTheme.slate500)
                                }
                            }
                            .padding(.vertical, 4)
                        }
                    }
                    .listStyle(.plain)
                }
            }
            .navigationTitle("Attendance Logs")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItemGroup(placement: .primaryAction) {
                    Button {
                        showMonthlyReport = true
                    } label: {
                        Image(systemName: "doc.text.fill")
                    }
                    Button {
                        loadAttendance()
                    } label: {
                        Image(systemName: "arrow.clockwise")
                    }
                }
            }
            .onAppear {
                loadAttendance()
            }
            .sheet(isPresented: $showMonthlyReport) {
                let targetId = api.currentUser?.employeeId ?? api.currentUser?.id ?? records.first?.employeeId ?? ""
                MonthlyAttendanceReportSheetView(initialEmployeeId: targetId, isEmployeeLocked: true)
            }
        }
    }

    private func loadAttendance() {
        Task {
            isLoading = true
            records = await api.getAttendance()
            isLoading = false
        }
    }
}

