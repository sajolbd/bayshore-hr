import SwiftUI

public struct EmployeeLeaveView: View {
    @ObservedObject var api = BayshoreApiClient.shared

    @State private var showApplySheet: Bool = false
    @State private var leaveType: String = "Casual"
    @State private var startDate: Date = Date()
    @State private var endDate: Date = Date()
    @State private var reason: String = ""

    public init() {}

    public var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    // Balance Cards
                    HStack(spacing: 10) {
                        VStack(spacing: 4) {
                            Text("Annual Leave")
                                .font(.caption2)
                                .foregroundColor(BayshoreTheme.slate500)
                            Text("14 Days")
                                .font(.headline)
                                .fontWeight(.bold)
                                .foregroundColor(BayshoreTheme.orange)
                        }
                        .frame(maxWidth: .infinity)
                        .bayshoreCard()

                        VStack(spacing: 4) {
                            Text("Casual Leave")
                                .font(.caption2)
                                .foregroundColor(BayshoreTheme.slate500)
                            Text("8 Days")
                                .font(.headline)
                                .fontWeight(.bold)
                                .foregroundColor(BayshoreTheme.emerald600)
                        }
                        .frame(maxWidth: .infinity)
                        .bayshoreCard()

                        VStack(spacing: 4) {
                            Text("Medical Leave")
                                .font(.caption2)
                                .foregroundColor(BayshoreTheme.slate500)
                            Text("10 Days")
                                .font(.headline)
                                .fontWeight(.bold)
                                .foregroundColor(BayshoreTheme.amber600)
                        }
                        .frame(maxWidth: .infinity)
                        .bayshoreCard()
                    }

                    // Apply Button
                    Button {
                        showApplySheet = true
                    } label: {
                        HStack {
                            Image(systemName: "plus.circle.fill")
                            Text("Apply for Leave")
                                .fontWeight(.bold)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(14)
                        .background(BayshoreTheme.orange)
                        .foregroundColor(.white)
                        .cornerRadius(12)
                    }

                    // Leave History
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Recent Leave Requests")
                            .font(.subheadline)
                            .fontWeight(.bold)
                            .foregroundColor(BayshoreTheme.slate900)

                        VStack(alignment: .leading, spacing: 8) {
                            HStack {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text("Casual Leave • 2 Days")
                                        .font(.caption)
                                        .fontWeight(.bold)
                                    Text("Nov 18, 2026 → Nov 19, 2026 • Family commitment")
                                        .font(.caption2)
                                        .foregroundColor(BayshoreTheme.slate500)
                                }
                                Spacer()
                                StatusBadgeView(status: "Approved")
                            }
                        }
                        .bayshoreCard()
                    }
                }
                .padding(16)
            }
            .navigationTitle("Leave Management")
            .navigationBarTitleDisplayMode(.inline)
            .sheet(isPresented: $showApplySheet) {
                NavigationStack {
                    Form {
                        Section("Leave Type") {
                            Picker("Type", selection: $leaveType) {
                                Text("Casual Leave").tag("Casual")
                                Text("Annual Leave").tag("Annual")
                                Text("Medical Leave").tag("Medical")
                            }
                            .pickerStyle(.segmented)
                        }

                        Section("Date Range") {
                            DatePicker("Start Date", selection: $startDate, displayedComponents: .date)
                            DatePicker("End Date", selection: $endDate, displayedComponents: .date)
                        }

                        Section("Reason") {
                            TextField("Enter reason for leave...", text: $reason)
                        }

                        Section {
                            Button("Submit Application") {
                                showApplySheet = false
                            }
                            .buttonStyle(.borderedProminent)
                            .tint(BayshoreTheme.orange)
                            .frame(maxWidth: .infinity)
                        }
                    }
                    .navigationTitle("Apply for Leave")
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .cancellationAction) {
                            Button("Cancel") { showApplySheet = false }
                        }
                    }
                }
            }
        }
    }
}

