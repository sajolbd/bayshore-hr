import SwiftUI
import PhotosUI

public struct EmployeeProfileView: View {
    @ObservedObject var api = BayshoreApiClient.shared

    @State private var selectedPhotoItem: PhotosPickerItem?
    @State private var profileImage: Image?
    @State private var isUploadingPhoto: Bool = false
    @State private var showSignOutAlert: Bool = false

    public init() {}

    public var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    // Profile Header Card
                    VStack(spacing: 12) {
                        ZStack(alignment: .bottomTrailing) {
                            if let img = profileImage {
                                img
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 88, height: 88)
                                    .clipShape(Circle())
                            } else {
                                BayshoreLogoView(size: 88)
                            }

                            PhotosPicker(selection: $selectedPhotoItem, matching: .images) {
                                Image(systemName: "camera.fill")
                                    .font(.system(size: 13, weight: .bold))
                                    .foregroundColor(.white)
                                    .padding(7)
                                    .background(BayshoreTheme.orange)
                                    .clipShape(Circle())
                                    .overlay(Circle().stroke(Color.white, lineWidth: 2))
                            }
                        }

                        VStack(spacing: 4) {
                            Text(api.currentUser?.name ?? "Team Member")
                                .font(.title3)
                                .fontWeight(.bold)
                                .foregroundColor(BayshoreTheme.slate900)
                            Text("\(api.currentUser?.role ?? "Staff") • \(api.currentUser?.department ?? "Engineering")")
                                .font(.footnote)
                                .foregroundColor(BayshoreTheme.slate500)
                        }

                        // 100% Onsite Badge
                        HStack(spacing: 6) {
                            Image(systemName: "building.2.fill")
                                .foregroundColor(BayshoreTheme.emerald600)
                            Text("100% Onsite (Gulshan HQ, Dhaka)")
                                .font(.caption2)
                                .fontWeight(.semibold)
                                .foregroundColor(BayshoreTheme.emerald600)
                        }
                        .padding(.horizontal, 10)
                        .padding(.vertical, 4)
                        .background(BayshoreTheme.emerald50)
                        .clipShape(Capsule())
                    }
                    .frame(maxWidth: .infinity)
                    .bayshoreCard()

                    // Workplace Governance
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Workplace & Attendance Policy")
                            .font(.caption)
                            .fontWeight(.bold)
                            .foregroundColor(BayshoreTheme.slate700)

                        VStack(spacing: 8) {
                            HStack {
                                Text("Assigned Office")
                                    .font(.caption)
                                    .foregroundColor(BayshoreTheme.slate500)
                                Spacer()
                                Text("Gulshan HQ (Dhaka)")
                                    .font(.caption)
                                    .fontWeight(.bold)
                            }
                            Divider()
                            HStack {
                                Text("Weekly Schedule")
                                    .font(.caption)
                                    .foregroundColor(BayshoreTheme.slate500)
                                Spacer()
                                Text("Sun – Thu (09:00 AM – 06:00 PM)")
                                    .font(.caption)
                                    .fontWeight(.bold)
                            }
                            Divider()
                            HStack {
                                Text("Reporting Lead")
                                    .font(.caption)
                                    .foregroundColor(BayshoreTheme.slate500)
                                Spacer()
                                Text("Shamim Ahsan (Super Admin)")
                                    .font(.caption)
                                    .fontWeight(.bold)
                            }
                        }
                    }
                    .bayshoreCard()

                    // Account Actions
                    VStack(spacing: 10) {
                        Button {
                            showSignOutAlert = true
                        } label: {
                            HStack {
                                Image(systemName: "rectangle.portrait.and.arrow.right")
                                Text("Sign Out of Bayshore HR")
                                    .fontWeight(.semibold)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(12)
                            .background(BayshoreTheme.slate900)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                        }
                    }
                    .padding(.horizontal, 4)
                }
                .padding(16)
            }
            .navigationTitle("Account & Profile")
            .navigationBarTitleDisplayMode(.inline)
            .alert("Sign Out?", isPresented: $showSignOutAlert) {
                Button("Cancel", role: .cancel) {}
                Button("Sign Out", role: .destructive) {
                    Task { await api.logout() }
                }
            } message: {
                Text("Are you sure you want to sign out from Bayshore HR?")
            }
            .onChange(of: selectedPhotoItem) { _, newItem in
                guard let item = newItem else { return }
                Task {
                    if let data = try? await item.loadTransferable(type: Data.self),
                       let uiImg = UIImage(data: data) {
                        profileImage = Image(uiImage: uiImg)
                    }
                }
            }
        }
    }
}

