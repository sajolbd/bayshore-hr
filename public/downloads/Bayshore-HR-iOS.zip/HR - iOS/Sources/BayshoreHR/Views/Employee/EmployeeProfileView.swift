import SwiftUI
import PhotosUI

public struct EmployeeProfileView: View {
    @ObservedObject var api = BayshoreApiClient.shared

    @State private var selectedPhotoItem: PhotosPickerItem?
    @State private var profileImage: Image?
    @State private var isUploadingPhoto: Bool = false
    @State private var showSignOutAlert: Bool = false
    @State private var showEditSheet: Bool = false
    @State private var editPhone: String = ""
    @State private var editLocation: String = ""
    @State private var editBloodGroup: String = ""
    @State private var editDateOfBirth: String = ""
    @State private var editNid: String = ""
    @State private var isSavingProfile: Bool = false
    @State private var saveMessage: String = ""

    public init() {}

    public var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    // Profile Header Card
                    VStack(spacing: 12) {
                        ZStack(alignment: .bottomTrailing) {
                            if let img = profileImage {
                                img
                                    .resizable()
                                    .scaledToFill()
                                    .frame(width: 88, height: 88)
                                    .clipShape(Circle())
                            } else {
                                BayshoreLogoView(size: 88)
                            }

                            PhotosPicker(selection: $selectedPhotoItem, matching: .images) {
                                Image(systemName: "camera.fill")
                                    .font(.system(size: 13, weight: .bold))
                                    .foregroundColor(.white)
                                    .padding(7)
                                    .background(BayshoreTheme.orange)
                                    .clipShape(Circle())
                                    .overlay(Circle().stroke(Color.white, lineWidth: 2))
                            }
                        }

                        VStack(spacing: 4) {
                            Text(api.currentUser?.name ?? "Team Member")
                                .font(.title3)
                                .fontWeight(.bold)
                                .foregroundColor(BayshoreTheme.slate900)
                            Text("\(api.currentUser?.role ?? "Staff") • \(api.currentUser?.department ?? "Engineering")")
                                .font(.footnote)
                                .foregroundColor(BayshoreTheme.slate500)
                        }

                        // 100% Onsite Badge
                        HStack(spacing: 6) {
                            Image(systemName: "building.2.fill")
                                .foregroundColor(BayshoreTheme.emerald600)
                            Text("100% Onsite (Abtab Nagar HQ, Dhaka)")
                                .font(.caption2)
                                .fontWeight(.semibold)
                                .foregroundColor(BayshoreTheme.emerald600)
                        }
                        .padding(.horizontal, 10)
                        .padding(.vertical, 4)
                        .background(BayshoreTheme.emerald50)
                        .clipShape(Capsule())
                    }
                    .frame(maxWidth: .infinity)
                    .bayshoreCard()

                    // Personal Details Card
                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            Text("Personal Details")
                                .font(.caption)
                                .fontWeight(.bold)
                                .foregroundColor(BayshoreTheme.slate700)
                            Spacer()
                            Button {
                                editPhone = api.currentUser?.phone ?? ""
                                editLocation = api.currentUser?.location ?? ""
                                editBloodGroup = api.currentUser?.bloodGroup ?? "O+"
                                editDateOfBirth = api.currentUser?.dateOfBirth ?? ""
                                editNid = api.currentUser?.nidOrPassport ?? ""
                                saveMessage = ""
                                showEditSheet = true
                            } label: {
                                HStack(spacing: 4) {
                                    Image(systemName: "pencil")
                                    Text("Edit Info")
                                }
                                .font(.caption2)
                                .fontWeight(.semibold)
                                .foregroundColor(BayshoreTheme.orange)
                            }
                        }

                        VStack(spacing: 8) {
                            HStack {
                                Text("Date of Birth")
                                    .font(.caption)
                                    .foregroundColor(BayshoreTheme.slate500)
                                Spacer()
                                Text(api.currentUser?.dateOfBirth.flatMap { $0.isEmpty ? nil : $0 } ?? "Not Specified")
                                    .font(.caption)
                                    .fontWeight(.bold)
                            }
                            Divider()
                            HStack {
                                Text("National ID / Passport")
                                    .font(.caption)
                                    .foregroundColor(BayshoreTheme.slate500)
                                Spacer()
                                Text(api.currentUser?.nidOrPassport.flatMap { $0.isEmpty ? nil : $0 } ?? "Pending Verification")
                                    .font(.caption)
                                    .fontWeight(.bold)
                            }
                            Divider()
                            HStack {
                                Text("Phone")
                                    .font(.caption)
                                    .foregroundColor(BayshoreTheme.slate500)
                                Spacer()
                                Text(api.currentUser?.phone.flatMap { $0.isEmpty ? nil : $0 } ?? "—")
                                    .font(.caption)
                                    .fontWeight(.bold)
                            }
                            Divider()
                            HStack {
                                Text("Blood Group")
                                    .font(.caption)
                                    .foregroundColor(BayshoreTheme.slate500)
                                Spacer()
                                Text(api.currentUser?.bloodGroup.flatMap { $0.isEmpty ? nil : $0 } ?? "O+")
                                    .font(.caption)
                                    .fontWeight(.bold)
                            }
                        }
                    }
                    .bayshoreCard()

                    // Workplace Governance
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Workplace & Attendance Policy")
                            .font(.caption)
                            .fontWeight(.bold)
                            .foregroundColor(BayshoreTheme.slate700)

                        VStack(spacing: 8) {
                            HStack {
                                Text("Assigned Office")
                                    .font(.caption)
                                    .foregroundColor(BayshoreTheme.slate500)
                                Spacer()
                                Text("Abtab Nagar HQ (Dhaka)")
                                    .font(.caption)
                                    .fontWeight(.bold)
                            }
                            Divider()
                            HStack {
                                Text("Weekly Schedule")
                                    .font(.caption)
                                    .foregroundColor(BayshoreTheme.slate500)
                                Spacer()
                                Text("Sun – Thu (09:00 AM – 06:00 PM)")
                                    .font(.caption)
                                    .fontWeight(.bold)
                            }
                            Divider()
                            HStack {
                                Text("Reporting Lead")
                                    .font(.caption)
                                    .foregroundColor(BayshoreTheme.slate500)
                                Spacer()
                                Text("Shamim Ahsan (Super Admin)")
                                    .font(.caption)
                                    .fontWeight(.bold)
                            }
                        }
                    }
                    .bayshoreCard()

                    // Account Actions
                    VStack(spacing: 10) {
                        Button {
                            showSignOutAlert = true
                        } label: {
                            HStack {
                                Image(systemName: "rectangle.portrait.and.arrow.right")
                                Text("Sign Out of Bayshore HR")
                                    .fontWeight(.semibold)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(12)
                            .background(BayshoreTheme.slate900)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                        }
                    }
                    .padding(.horizontal, 4)
                }
                .padding(16)
            }
            .navigationTitle("Account & Profile")
            .navigationBarTitleDisplayMode(.inline)
            .alert("Sign Out?", isPresented: $showSignOutAlert) {
                Button("Cancel", role: .cancel) {}
                Button("Sign Out", role: .destructive) {
                    Task { await api.logout() }
                }
            } message: {
                Text("Are you sure you want to sign out from Bayshore HR?")
            }
            .onChange(of: selectedPhotoItem) { _, newItem in
                guard let item = newItem else { return }
                Task {
                    if let data = try? await item.loadTransferable(type: Data.self),
                       let uiImg = UIImage(data: data) {
                        profileImage = Image(uiImage: uiImg)
                    }
                }
            }
            .task {
                await api.fetchProfile()
            }
            .sheet(isPresented: $showEditSheet) {
                NavigationStack {
                    Form {
                        Section(header: Text("Personal Information")) {
                            VStack(alignment: .leading, spacing: 4) {
                                Text("Date of Birth")
                                    .font(.caption2)
                                    .foregroundColor(BayshoreTheme.slate500)
                                TextField("YYYY-MM-DD (e.g. 1995-08-14)", text: $editDateOfBirth)
                            }
                            VStack(alignment: .leading, spacing: 4) {
                                Text("National ID / Passport")
                                    .font(.caption2)
                                    .foregroundColor(BayshoreTheme.slate500)
                                TextField("NID or Smart Card number", text: $editNid)
                            }
                            VStack(alignment: .leading, spacing: 4) {
                                Text("Phone Number")
                                    .font(.caption2)
                                    .foregroundColor(BayshoreTheme.slate500)
                                TextField("+880 1XXXXXXXXX", text: $editPhone)
                                    .keyboardType(.phonePad)
                            }
                            VStack(alignment: .leading, spacing: 4) {
                                Text("Residential Location")
                                    .font(.caption2)
                                    .foregroundColor(BayshoreTheme.slate500)
                                TextField("e.g. Abtab Nagar, Dhaka", text: $editLocation)
                            }
                            VStack(alignment: .leading, spacing: 4) {
                                Text("Blood Group")
                                    .font(.caption2)
                                    .foregroundColor(BayshoreTheme.slate500)
                                TextField("e.g. A+, B+, O+, AB+", text: $editBloodGroup)
                            }
                        }

                        if !saveMessage.isEmpty {
                            Section {
                                Text(saveMessage)
                                    .font(.caption)
                                    .foregroundColor(saveMessage.contains("failed") ? BayshoreTheme.red600 : BayshoreTheme.emerald600)
                            }
                        }
                    }
                    .navigationTitle("Edit Profile")
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .cancellationAction) {
                            Button("Cancel") {
                                showEditSheet = false
                            }
                        }
                        ToolbarItem(placement: .confirmationAction) {
                            Button {
                                Task {
                                    isSavingProfile = true
                                    let ok = await api.updateProfile(
                                        phone: editPhone,
                                        location: editLocation,
                                        bloodGroup: editBloodGroup,
                                        dateOfBirth: editDateOfBirth,
                                        nidOrPassport: editNid
                                    )
                                    isSavingProfile = false
                                    if ok {
                                        saveMessage = "Profile updated successfully!"
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
                                            showEditSheet = false
                                        }
                                    } else {
                                        saveMessage = "Update failed. Please try again."
                                    }
                                }
                            } label: {
                                if isSavingProfile {
                                    ProgressView()
                                } else {
                                    Text("Save")
                                        .fontWeight(.semibold)
                                }
                            }
                            .disabled(isSavingProfile)
                        }
                    }
                }
                .presentationDetents([.medium, .large])
            }
        }
    }
}

