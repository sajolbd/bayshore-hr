import SwiftUI

public struct EmployeeHomeView: View {
    @ObservedObject var api = BayshoreApiClient.shared
    @ObservedObject var loc = LocationManager.shared

    @State private var isClockedIn: Bool = false
    @State private var checkInTime: String?
    @State private var hasClockedOutToday: Bool = false
    @State private var isPunching: Bool = false

    public init() {}

    public var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    // Welcome Header
                    HStack(spacing: 12) {
                        BayshoreLogoView(size: 44)
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Good day, \(api.currentUser?.name ?? "Team Member") 👋")
                                .font(.headline)
                                .foregroundColor(BayshoreTheme.slate900)
                            Text("Abtab Nagar HQ • Level 2, Road 1, Block A")
                                .font(.caption)
                                .foregroundColor(BayshoreTheme.slate500)
                            Text("Shift: \(formatShiftTime12h(api.currentUser?.officeInTime)) – \(formatShiftTime12h(api.currentUser?.officeOutTime, fallback: "06:00 PM"))")
                                .font(.caption2)
                                .fontWeight(.semibold)
                                .foregroundColor(BayshoreTheme.emerald600)
                        }
                        Spacer()
                    }
                    .padding(.horizontal, 4)

                    // Office Check-In Card
                    VStack(spacing: 14) {
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text("DAILY TIME CLOCK")
                                    .font(.caption2)
                                    .fontWeight(.bold)
                                    .foregroundColor(BayshoreTheme.orange)
                                Text(isClockedIn ? "Currently on Duty" : "Not Clocked In Today")
                                    .font(.title3)
                                    .fontWeight(.bold)
                                    .foregroundColor(BayshoreTheme.slate900)
                            }
                            Spacer()
                            StatusBadgeView(status: isClockedIn ? "On Duty" : "Off Duty")
                        }

                        // Location Verification Pill
                        HStack(spacing: 6) {
                            Image(systemName: loc.isInsideOffice ? "checkmark.circle.fill" : "location.circle")
                                .foregroundColor(loc.isInsideOffice ? BayshoreTheme.emerald600 : BayshoreTheme.amber600)
                            Text(loc.isInsideOffice ? "Inside Office (Abtab Nagar HQ)" : "Location Verified: Dhaka (\(Int(loc.distanceFromHQMeters))m from HQ)")
                                .font(.caption)
                                .foregroundColor(BayshoreTheme.slate700)
                            Spacer()
                        }
                        .padding(10)
                        .background(loc.isInsideOffice ? BayshoreTheme.emerald50 : BayshoreTheme.amber50)
                        .cornerRadius(8)

                        if let checkIn = checkInTime {
                            HStack {
                                Text("Check-In Time:")
                                    .font(.caption)
                                    .foregroundColor(BayshoreTheme.slate500)
                                Text(checkIn)
                                    .font(.caption)
                                    .fontWeight(.bold)
                                Spacer()
                            }
                        }

                        if !isClockedIn && hasClockedOutToday {
                            HStack(spacing: 6) {
                                Image(systemName: "exclamationmark.triangle.fill")
                                    .foregroundColor(BayshoreTheme.amber600)
                                Text("Clocked out today. Punched out by mistake? You can re-clock in anytime to resume your shift.")
                                    .font(.caption2)
                                    .foregroundColor(BayshoreTheme.slate700)
                            }
                            .padding(10)
                            .background(BayshoreTheme.amber50)
                            .cornerRadius(8)
                        }

                        Button {
                            Task {
                                isPunching = true
                                if isClockedIn {
                                    let ok = await api.clockOut()
                                    if ok {
                                        isClockedIn = false
                                        hasClockedOutToday = true
                                    }
                                } else {
                                    let ok = await api.clockIn(
                                        lat: LocationManager.hqLatitude,
                                        lng: LocationManager.hqLongitude,
                                        address: "Level 2, Road 1, Block A, Abtab Nagar, Dhaka"
                                    )
                                    if ok {
                                        isClockedIn = true
                                        hasClockedOutToday = false
                                        let formatter = DateFormatter()
                                        formatter.timeStyle = .short
                                        checkInTime = formatter.string(from: Date())
                                    }
                                }
                                isPunching = false
                            }
                        } label: {
                            HStack {
                                if isPunching {
                                    ProgressView().tint(.white)
                                }
                                Image(systemName: isClockedIn ? "stop.circle.fill" : "play.circle.fill")
                                Text(isClockedIn ? "Clock Out (End Shift)" : (hasClockedOutToday ? "Re-Clock In (Resume Shift)" : "Clock In (Office Check-In)"))
                                    .fontWeight(.bold)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(14)
                            .background(isClockedIn ? BayshoreTheme.slate900 : BayshoreTheme.emerald600)
                            .foregroundColor(.white)
                            .cornerRadius(12)
                        }
                        .disabled(isPunching)
                    }
                    .bayshoreCard()

                    // Monthly Summary (100% Onsite Abtab Nagar HQ)
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Monthly Summary (November 2026)")
                            .font(.subheadline)
                            .fontWeight(.bold)
                            .foregroundColor(BayshoreTheme.slate900)

                        LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                            KpiCardView(title: "Working Days", value: "22 Days", subtitle: "Sun - Thu Week", iconName: "calendar", color: BayshoreTheme.orange)
                            KpiCardView(title: "Present Onsite", value: "18 Days", subtitle: "100% Office Compliance", iconName: "person.crop.circle.badge.checkmark", color: BayshoreTheme.emerald600)
                            KpiCardView(title: "Late Punches", value: "1 Day", subtitle: "Nov 04 (09:35 AM)", iconName: "clock.badge.exclamationmark", color: BayshoreTheme.amber600)
                            KpiCardView(title: "Approved Leaves", value: "3 Days", subtitle: "2 Casual • 1 Annual", iconName: "sun.max", color: BayshoreTheme.orange)
                        }
                    }

                    // Office Policies Card
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Onsite Governance Note")
                            .font(.caption)
                            .fontWeight(.bold)
                            .foregroundColor(BayshoreTheme.slate700)
                        Text("All Bayshore Communication staff work 100% onsite at the Abtab Nagar HQ. Shifts commence at 09:00 AM Sun - Thu.")
                            .font(.caption2)
                            .foregroundColor(BayshoreTheme.slate500)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .bayshoreCard()
                }
                .padding(16)
            }
            .navigationTitle("Self-Service")
            .navigationBarTitleDisplayMode(.inline)
            .onAppear {
                loc.requestPermission()
                loc.startUpdating()
            }
        }
    }
}

