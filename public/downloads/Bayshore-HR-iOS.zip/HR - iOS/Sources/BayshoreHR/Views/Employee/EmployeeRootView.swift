import SwiftUI

public struct EmployeeRootView: View {
    public init() {}

    public var body: some View {
        TabView {
            EmployeeHomeView()
                .tabItem {
                    Label("Home", systemImage: "house.fill")
                }

            EmployeeAttendanceView()
                .tabItem {
                    Label("Attendance", systemImage: "clock.fill")
                }

            EmployeeLeaveView()
                .tabItem {
                    Label("Leave", systemImage: "calendar")
                }

            EmployeeProfileView()
                .tabItem {
                    Label("Profile", systemImage: "person.crop.circle")
                }
        }
        .tint(BayshoreTheme.orange)
    }
}

