import SwiftUI
import UIKit

public struct MonthlyAttendanceReportSheetView: View {
    @ObservedObject var api = BayshoreApiClient.shared
    @Environment(\.dismiss) private var dismiss

    public let initialEmployeeId: String
    public let isEmployeeLocked: Bool

    @State private var selectedEmployeeId: String
    @State private var selectedMonthDate: Date = Date()
    @State private var selectedMonthKey: String = dhakaCurrentMonthKey()
    @State private var employees: [EmployeeItem] = []
    @State private var report: MonthlyAttendanceReport?
    @State private var isLoading: Bool = false
    @State private var isExporting: Bool = false
    @State private var shareFileURL: URL?
    @State private var showShareSheet: Bool = false
    @State private var errorMessage: String?

    public init(initialEmployeeId: String, isEmployeeLocked: Bool = false) {
        self.initialEmployeeId = initialEmployeeId
        self.isEmployeeLocked = isEmployeeLocked
        _selectedEmployeeId = State(initialValue: initialEmployeeId)
    }

    private var monthDisplayTitle: String {
        let fmt = DateFormatter()
        fmt.dateFormat = "MMMM yyyy"
        fmt.timeZone = TimeZone(identifier: "Asia/Dhaka") ?? .current
        return fmt.string(from: selectedMonthDate)
    }

    public var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 14) {
                    controlsCard

                    if isLoading {
                        HStack {
                            Spacer()
                            ProgressView("Loading monthly report...")
                            Spacer()
                        }
                        .padding(.vertical, 32)
                    } else if let err = errorMessage {
                        Text(err)
                            .font(.footnote)
                            .foregroundColor(BayshoreTheme.red600)
                            .padding()
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(BayshoreTheme.red50)
                            .cornerRadius(10)
                    } else if let report = report {
                        summaryCard(report: report)
                        exportButton(report: report)
                        rowsCard(report: report)
                    } else {
                        Text("Select an employee and month to inspect attendance.")
                            .font(.footnote)
                            .foregroundColor(BayshoreTheme.slate500)
                            .padding(.vertical, 20)
                    }
                }
                .padding(16)
            }
            .background(BayshoreTheme.slate50)
            .navigationTitle("Monthly Excel Report")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Close") { dismiss() }
                }
            }
            .onAppear {
                Task { await bootstrapAndLoad() }
            }
            .sheet(isPresented: $showShareSheet) {
                if let url = shareFileURL {
                    ActivityShareSheet(activityItems: [url])
                }
            }
        }
    }

    private var controlsCard: some View {
        VStack(alignment: .leading, spacing: 10) {
            if !isEmployeeLocked && !employees.isEmpty {
                VStack(alignment: .leading, spacing: 4) {
                    Text("EMPLOYEE")
                        .font(.caption2)
                        .fontWeight(.bold)
                        .foregroundColor(BayshoreTheme.slate500)
                    Picker("Employee", selection: $selectedEmployeeId) {
                        ForEach(employees) { emp in
                            Text("\(emp.name) (\(emp.department))").tag(emp.id)
                        }
                    }
                    .pickerStyle(.menu)
                    .onChange(of: selectedEmployeeId) { _ in
                        Task { await loadReport() }
                    }
                }
            }

            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("REPORT MONTH")
                        .font(.caption2)
                        .fontWeight(.bold)
                        .foregroundColor(BayshoreTheme.slate500)
                    Text("\(monthDisplayTitle) (\(selectedMonthKey))")
                        .font(.subheadline)
                        .fontWeight(.bold)
                        .foregroundColor(BayshoreTheme.slate900)
                }
                Spacer()
                HStack(spacing: 8) {
                    Button {
                        shiftMonth(by: -1)
                    } label: {
                        Image(systemName: "chevron.left")
                            .padding(8)
                            .background(BayshoreTheme.slate100)
                            .foregroundColor(BayshoreTheme.slate700)
                            .cornerRadius(8)
                    }
                    Button {
                        shiftMonth(by: 1)
                    } label: {
                        Image(systemName: "chevron.right")
                            .padding(8)
                            .background(BayshoreTheme.slate100)
                            .foregroundColor(BayshoreTheme.slate700)
                            .cornerRadius(8)
                    }
                }
            }
        }
        .bayshoreCard()
    }

    private func summaryCard(report: MonthlyAttendanceReport) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text(report.employee.name)
                        .font(.headline)
                        .foregroundColor(BayshoreTheme.slate900)
                    Text("\(report.employee.role) • \(report.employee.department)")
                        .font(.caption)
                        .foregroundColor(BayshoreTheme.slate500)
                }
                Spacer()
                VStack(alignment: .trailing, spacing: 2) {
                    Text("OFFICE HOURS")
                        .font(.caption2)
                        .fontWeight(.bold)
                        .foregroundColor(BayshoreTheme.slate500)
                    Text("\(report.officeIn12h) – \(report.officeOut12h)")
                        .font(.caption)
                        .fontWeight(.semibold)
                        .foregroundColor(BayshoreTheme.slate800)
                }
            }

            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 8) {
                miniStat("Logged / Present", "\(report.summary.totalLoggedDays) / \(report.summary.presentDays) d", BayshoreTheme.slate900, BayshoreTheme.slate100)
                miniStat("On-Time Days", "\(report.summary.onTimeDays) days", BayshoreTheme.emerald600, BayshoreTheme.emerald50)
                miniStat("Late Clock-Ins", "\(report.summary.lateDays) d (\(report.summary.totalLateFormatted))", BayshoreTheme.red600, BayshoreTheme.red50)
                miniStat("Total Hours", report.summary.totalWorkFormatted, BayshoreTheme.orange, BayshoreTheme.orangeSoft)
            }
        }
        .bayshoreCard()
    }

    private func miniStat(_ label: String, _ value: String, _ tint: Color, _ bg: Color) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(label)
                .font(.caption2)
                .foregroundColor(BayshoreTheme.slate500)
            Text(value)
                .font(.subheadline)
                .fontWeight(.bold)
                .foregroundColor(tint)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(10)
        .background(bg)
        .cornerRadius(10)
    }

    private func exportButton(report: MonthlyAttendanceReport) -> some View {
        Button {
            Task {
                isExporting = true
                let url = await api.downloadMonthlyReportXlsx(employeeId: selectedEmployeeId, month: selectedMonthKey)
                isExporting = false
                if let url = url {
                    shareFileURL = url
                    showShareSheet = true
                } else {
                    errorMessage = "Could not download Excel file from server."
                }
            }
        } label: {
            HStack {
                if isExporting {
                    ProgressView().tint(.white)
                } else {
                    Image(systemName: "arrow.down.doc.fill")
                }
                Text(isExporting ? "Generating Excel (.xlsx)..." : "Download Excel (.xlsx) — \(report.monthLabel)")
                    .fontWeight(.bold)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 12)
            .background(BayshoreTheme.emerald600)
            .foregroundColor(.white)
            .cornerRadius(12)
        }
        .disabled(isExporting)
    }

    private func rowsCard(report: MonthlyAttendanceReport) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("DAILY LOGS (\(report.rows.count)) • Late check-ins highlighted in RED")
                .font(.caption)
                .fontWeight(.bold)
                .foregroundColor(BayshoreTheme.slate700)

            if report.rows.isEmpty {
                Text("No attendance entries recorded for \(report.monthLabel).")
                    .font(.footnote)
                    .foregroundColor(BayshoreTheme.slate500)
                    .padding(.vertical, 8)
            } else {
                ForEach(report.rows) { row in
                    VStack(alignment: .leading, spacing: 6) {
                        HStack {
                            Text("\(row.dateKey) (\(row.dayLabel))")
                                .font(.subheadline)
                                .fontWeight(.bold)
                                .foregroundColor(BayshoreTheme.slate900)
                            Spacer()
                            StatusBadgeView(status: row.effectiveStatus)
                        }

                        HStack(spacing: 10) {
                            if row.isLate {
                                Text("In: \(row.checkInDisplay) (\(row.lateMinutes)m late)")
                                    .font(.caption)
                                    .fontWeight(.heavy)
                                    .foregroundColor(BayshoreTheme.red600)
                                    .padding(.horizontal, 8)
                                    .padding(.vertical, 4)
                                    .background(BayshoreTheme.red50)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 6)
                                            .stroke(BayshoreTheme.red600.opacity(0.45), lineWidth: 1)
                                    )
                                    .cornerRadius(6)
                            } else {
                                Text("In: \(row.checkInDisplay)")
                                    .font(.caption)
                                    .fontWeight(.semibold)
                                    .foregroundColor(BayshoreTheme.emerald600)
                            }

                            Text("Out: \(row.checkOutDisplay)")
                                .font(.caption)
                                .foregroundColor(BayshoreTheme.slate700)

                            Spacer()

                            Text(row.workHours)
                                .font(.caption)
                                .fontWeight(.semibold)
                                .foregroundColor(BayshoreTheme.slate800)
                        }

                        Text("Shift: \(row.scheduledIn12h) – \(row.scheduledOut12h) • \(row.location)")
                            .font(.caption2)
                            .foregroundColor(BayshoreTheme.slate500)
                    }
                    .padding(10)
                    .background(row.isLate ? BayshoreTheme.red50.opacity(0.4) : BayshoreTheme.slate50)
                    .overlay(
                        RoundedRectangle(cornerRadius: 10)
                            .stroke(row.isLate ? BayshoreTheme.red600.opacity(0.3) : BayshoreTheme.slate200, lineWidth: 1)
                    )
                    .cornerRadius(10)
                }
            }
        }
        .bayshoreCard()
    }

    private func shiftMonth(by delta: Int) {
        let tz = TimeZone(identifier: "Asia/Dhaka") ?? .current
        var cal = Calendar.current
        cal.timeZone = tz
        if let updated = cal.date(byAdding: .month, value: delta, to: selectedMonthDate) {
            selectedMonthDate = updated
            let fmt = DateFormatter()
            fmt.dateFormat = "yyyy-MM"
            fmt.timeZone = tz
            selectedMonthKey = fmt.string(from: updated)
            Task { await loadReport() }
        }
    }

    private func bootstrapAndLoad() async {
        if !isEmployeeLocked && employees.isEmpty {
            employees = await api.getEmployees()
            if selectedEmployeeId.isEmpty, let first = employees.first {
                selectedEmployeeId = first.id
            }
        }
        await loadReport()
    }

    private func loadReport() async {
        guard !selectedEmployeeId.isEmpty else { return }
        isLoading = true
        errorMessage = nil
        let fetched = await api.getMonthlyAttendanceReport(employeeId: selectedEmployeeId, month: selectedMonthKey)
        isLoading = false
        if let fetched = fetched {
            report = fetched
        } else {
            report = nil
            errorMessage = "Unable to load report for \(selectedMonthKey)."
        }
    }
}

private struct ActivityShareSheet: UIViewControllerRepresentable {
    let activityItems: [Any]

    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: activityItems, applicationActivities: nil)
    }

    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}
