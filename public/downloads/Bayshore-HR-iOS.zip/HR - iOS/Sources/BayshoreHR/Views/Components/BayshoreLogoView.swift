import SwiftUI

public struct BayshoreLogoView: View {
    public var size: CGFloat = 56

    public init(size: CGFloat = 56) {
        self.size = size
    }

    public var body: some View {
        if let path = Bundle.module.path(forResource: "bayshore-circle-logo", ofType: "png", inDirectory: nil) ??
            Bundle.main.path(forResource: "bayshore-circle-logo", ofType: "png"),
           let uiImage = UIImage(contentsOfFile: path) {
            Image(uiImage: uiImage)
                .resizable()
                .scaledToFit()
                .frame(width: size, height: size)
                .clipShape(Circle())
        } else {
            Circle()
                .fill(BayshoreTheme.orange)
                .frame(width: size, height: size)
                .overlay(
                    Text("B")
                        .font(.system(size: size * 0.5, weight: .bold))
                        .foregroundColor(.white)
                )
        }
    }
}

