import SwiftUI

public struct AdminOverviewView: View {
    @ObservedObject var api = BayshoreApiClient.shared

    public init() {}

    public var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 16) {
                    // Header
                    HStack(spacing: 12) {
                        BayshoreLogoView(size: 40)
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Bayshore HR Admin Suite")
                                .font(.headline)
                                .foregroundColor(BayshoreTheme.slate900)
                            Text("Gulshan HQ • 100% Onsite Operations")
                                .font(.caption)
                                .foregroundColor(BayshoreTheme.slate500)
                        }
                        Spacer()
                    }

                    // KPI Grid
                    LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                        KpiCardView(title: "Total Staff", value: "248", subtitle: "All Onsite Gulshan HQ", iconName: "person.3.fill", color: BayshoreTheme.orange)
                        KpiCardView(title: "Present Today", value: "216", subtitle: "94.7% On-Time Record", iconName: "person.crop.circle.badge.checkmark", color: BayshoreTheme.emerald600)
                        KpiCardView(title: "Pending Leaves", value: "3", subtitle: "Awaiting Super Admin", iconName: "clock.badge.questionmark", color: BayshoreTheme.amber600)
                        KpiCardView(title: "Open Roles", value: "12", subtitle: "Active Recruitment", iconName: "briefcase.fill", color: BayshoreTheme.orange)
                    }

                    // Office Overview Card
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Office Operations Snapshot")
                            .font(.caption)
                            .fontWeight(.bold)
                            .foregroundColor(BayshoreTheme.slate700)
                        Text("Bayshore Communication operates 100% onsite at Gulshan HQ, Plot 14, Road 46, Gulshan-2, Dhaka 1212. All time clock punches are verified against the office geofence.")
                            .font(.caption2)
                            .foregroundColor(BayshoreTheme.slate500)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .bayshoreCard()
                }
                .padding(16)
            }
            .navigationTitle("Admin Overview")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}

