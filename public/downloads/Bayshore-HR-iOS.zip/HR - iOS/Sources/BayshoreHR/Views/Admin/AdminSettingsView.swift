import SwiftUI

public struct AdminSettingsView: View {
    @ObservedObject var api = BayshoreApiClient.shared

    @State private var showServerSheet: Bool = false
    @State private var showSignOutAlert: Bool = false

    public init() {}

    public var body: some View {
        NavigationStack {
            List {
                Section("Signed In Account") {
                    HStack(spacing: 12) {
                        BayshoreLogoView(size: 48)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(api.currentUser?.name ?? "Super Admin")
                                .font(.subheadline)
                                .fontWeight(.bold)
                            Text(api.currentUser?.email ?? "shamim@bayshore.com")
                                .font(.caption)
                                .foregroundColor(BayshoreTheme.slate500)
                            Text("Role: \(api.currentUser?.role ?? "Super Admin")")
                                .font(.caption2)
                                .foregroundColor(BayshoreTheme.orange)
                        }
                    }
                    .padding(.vertical, 4)
                }

                Section("Email & Invites") {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Super Admin Outbound Gmail")
                            .font(.subheadline)
                            .fontWeight(.medium)
                        Text("New employee invitation emails are dispatched directly from the Super Admin's address (\(api.currentUser?.email ?? "shamim@bayshore.com")) with automatic SMTP setup.")
                            .font(.caption2)
                            .foregroundColor(BayshoreTheme.slate500)
                    }
                    .padding(.vertical, 2)
                }

                Section("System & Diagnostics") {
                    Button {
                        showServerSheet = true
                    } label: {
                        HStack {
                            Image(systemName: "server.rack")
                                .foregroundColor(BayshoreTheme.orange)
                            VStack(alignment: .leading, spacing: 2) {
                                Text("Server Connection & Health")
                                    .foregroundColor(BayshoreTheme.slate900)
                                Text(api.serverURLString)
                                    .font(.caption2)
                                    .foregroundColor(BayshoreTheme.slate500)
                            }
                            Spacer()
                            Image(systemName: "chevron.right")
                                .font(.caption)
                                .foregroundColor(BayshoreTheme.slate500)
                        }
                    }
                }

                Section {
                    Button(role: .destructive) {
                        showSignOutAlert = true
                    } label: {
                        HStack {
                            Image(systemName: "rectangle.portrait.and.arrow.right")
                            Text("Sign Out")
                        }
                    }
                }
            }
            .navigationTitle("Admin Settings")
            .navigationBarTitleDisplayMode(.inline)
            .sheet(isPresented: $showServerSheet) {
                ServerConfigSheet()
            }
            .alert("Sign Out?", isPresented: $showSignOutAlert) {
                Button("Cancel", role: .cancel) {}
                Button("Sign Out", role: .destructive) {
                    Task { await api.logout() }
                }
            } message: {
                Text("Are you sure you want to sign out from Bayshore HR?")
            }
        }
    }
}

