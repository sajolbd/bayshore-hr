import SwiftUI

public struct AdminStaffView: View {
    @ObservedObject var api = BayshoreApiClient.shared

    @State private var employees: [EmployeeItem] = []
    @State private var isLoading: Bool = false
    @State private var searchQuery: String = ""
    @State private var showAddSheet: Bool = false
    @State private var editingEmployee: EmployeeItem?
    @State private var reportEmployee: EmployeeItem?

    // Add Form State
    @State private var newName: String = ""
    @State private var newEmail: String = ""
    @State private var newRole: String = ""
    @State private var newDepartment: String = "Engineering"
    @State private var newSalary: String = "60000"
    @State private var newOfficeInDate: Date = dateFromHHMM("09:00", defaultHour: 9, defaultMinute: 0)
    @State private var newOfficeOutDate: Date = dateFromHHMM("18:00", defaultHour: 18, defaultMinute: 0)

    public init() {}

    private var filteredEmployees: [EmployeeItem] {
        if searchQuery.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            return employees
        }
        let q = searchQuery.lowercased()
        return employees.filter {
            $0.name.lowercased().contains(q) ||
            $0.email.lowercased().contains(q) ||
            $0.role.lowercased().contains(q) ||
            $0.department.lowercased().contains(q)
        }
    }

    public var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // Search & Add Bar
                HStack(spacing: 8) {
                    TextField("Search employee name, role, email...", text: $searchQuery)
                        .padding(8)
                        .background(BayshoreTheme.slate50)
                        .cornerRadius(8)
                        .overlay(RoundedRectangle(cornerRadius: 8).stroke(BayshoreTheme.slate200, lineWidth: 1))
                        .font(.footnote)

                    Button {
                        showAddSheet = true
                    } label: {
                        HStack(spacing: 4) {
                            Image(systemName: "plus")
                            Text("Add")
                        }
                        .font(.footnote)
                        .fontWeight(.bold)
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .background(BayshoreTheme.orange)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                    }
                }
                .padding(14)
                .background(Color.white)
                .overlay(Rectangle().frame(height: 1).foregroundColor(BayshoreTheme.slate200), alignment: .bottom)

                // List
                if isLoading {
                    Spacer()
                    ProgressView("Loading employees...")
                    Spacer()
                } else if filteredEmployees.isEmpty {
                    Spacer()
                    Text("No employees found.")
                        .font(.footnote)
                        .foregroundColor(BayshoreTheme.slate500)
                    Spacer()
                } else {
                    List {
                        ForEach(filteredEmployees) { emp in
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(emp.name)
                                            .font(.subheadline)
                                            .fontWeight(.bold)
                                            .foregroundColor(BayshoreTheme.slate900)
                                        Text("\(emp.role) • \(emp.department)")
                                            .font(.caption)
                                            .foregroundColor(BayshoreTheme.slate500)
                                        Text(emp.email)
                                            .font(.caption2)
                                            .foregroundColor(BayshoreTheme.slate500)
                                        Text("Shift: \(formatShiftTime12h(emp.officeInTime)) – \(formatShiftTime12h(emp.officeOutTime, fallback: "06:00 PM"))")
                                            .font(.caption2)
                                            .fontWeight(.semibold)
                                            .foregroundColor(BayshoreTheme.emerald600)
                                    }
                                    Spacer()
                                    StatusBadgeView(status: emp.status)
                                }

                                HStack(spacing: 8) {
                                    Button {
                                        editingEmployee = emp
                                    } label: {
                                        HStack(spacing: 4) {
                                            Image(systemName: "pencil")
                                            Text("Edit")
                                        }
                                        .font(.caption2)
                                        .padding(.horizontal, 10)
                                        .padding(.vertical, 4)
                                        .background(BayshoreTheme.slate100)
                                        .foregroundColor(BayshoreTheme.slate700)
                                        .cornerRadius(6)
                                    }
                                    .buttonStyle(.plain)

                                    Button {
                                        reportEmployee = emp
                                    } label: {
                                        HStack(spacing: 4) {
                                            Image(systemName: "doc.text.fill")
                                            Text("Monthly Excel")
                                        }
                                        .font(.caption2)
                                        .padding(.horizontal, 10)
                                        .padding(.vertical, 4)
                                        .background(BayshoreTheme.emerald50)
                                        .foregroundColor(BayshoreTheme.emerald600)
                                        .cornerRadius(6)
                                    }
                                    .buttonStyle(.plain)

                                    Spacer()
                                    Text("৳\(Int(emp.salary))/mo")
                                        .font(.caption2)
                                        .fontWeight(.semibold)
                                        .foregroundColor(BayshoreTheme.slate700)
                                }
                            }
                            .padding(.vertical, 4)
                        }
                    }
                    .listStyle(.plain)
                }
            }
            .navigationTitle("Staff Directory")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .primaryAction) {
                    Button { loadEmployees() } label: { Image(systemName: "arrow.clockwise") }
                }
            }
            .onAppear { loadEmployees() }
            .sheet(isPresented: $showAddSheet) {
                addEmployeeSheet
            }
            .sheet(item: $editingEmployee) { emp in
                editEmployeeSheet(emp: emp)
            }
            .sheet(item: $reportEmployee) { emp in
                MonthlyAttendanceReportSheetView(initialEmployeeId: emp.id, isEmployeeLocked: false)
            }
        }
    }

    private var addEmployeeSheet: some View {
        NavigationStack {
            Form {
                Section("New Employee Details") {
                    TextField("Full Name", text: $newName)
                    TextField("Work Email", text: $newEmail)
                        .autocorrectionDisabled()
                        .textInputAutocapitalization(.never)
                        .keyboardType(.emailAddress)
                    TextField("Designation / Role", text: $newRole)
                    TextField("Department", text: $newDepartment)
                    TextField("Monthly Salary (BDT)", text: $newSalary)
                        .keyboardType(.numberPad)
                }

                Section("Office Schedule Hours") {
                    DatePicker("Office In Time", selection: $newOfficeInDate, displayedComponents: .hourAndMinute)
                    DatePicker("Office Out Time", selection: $newOfficeOutDate, displayedComponents: .hourAndMinute)
                }

                Section {
                    Text("Clock-ins after the assigned Office In Time will automatically be flagged as Late and marked RED in Monthly Excel Reports.")
                        .font(.caption2)
                        .foregroundColor(BayshoreTheme.slate500)
                }

                Section {
                    Button("Add Employee & Dispatch Invite") {
                        Task {
                            let sal = Double(newSalary) ?? 60000.0
                            let ok = await api.addEmployee(
                                name: newName,
                                email: newEmail,
                                role: newRole,
                                department: newDepartment,
                                salary: sal,
                                officeInTime: hhmmString(from: newOfficeInDate),
                                officeOutTime: hhmmString(from: newOfficeOutDate)
                            )
                            if ok {
                                showAddSheet = false
                                newName = ""
                                newEmail = ""
                                newRole = ""
                                newOfficeInDate = dateFromHHMM("09:00", defaultHour: 9, defaultMinute: 0)
                                newOfficeOutDate = dateFromHHMM("18:00", defaultHour: 18, defaultMinute: 0)
                                loadEmployees()
                            }
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(BayshoreTheme.orange)
                    .disabled(newName.isEmpty || newEmail.isEmpty || newRole.isEmpty)
                }
            }
            .navigationTitle("Add Employee")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { showAddSheet = false }
                }
            }
        }
    }

    private func editEmployeeSheet(emp: EmployeeItem) -> some View {
        EditEmployeeSheetView(employee: emp) {
            editingEmployee = nil
            loadEmployees()
        }
    }

    private func loadEmployees() {
        Task {
            isLoading = true
            employees = await api.getEmployees()
            isLoading = false
        }
    }
}

public struct EditEmployeeSheetView: View {
    @ObservedObject var api = BayshoreApiClient.shared
    public let employee: EmployeeItem
    public let onDone: () -> Void

    @State private var name: String
    @State private var role: String
    @State private var department: String
    @State private var salary: String
    @State private var status: String
    @State private var officeInDate: Date
    @State private var officeOutDate: Date

    public init(employee: EmployeeItem, onDone: @escaping () -> Void) {
        self.employee = employee
        self.onDone = onDone
        _name = State(initialValue: employee.name)
        _role = State(initialValue: employee.role)
        _department = State(initialValue: employee.department)
        _salary = State(initialValue: String(format: "%.0f", employee.salary))
        _status = State(initialValue: employee.status)
        _officeInDate = State(initialValue: dateFromHHMM(employee.officeInTime, defaultHour: 9, defaultMinute: 0))
        _officeOutDate = State(initialValue: dateFromHHMM(employee.officeOutTime, defaultHour: 18, defaultMinute: 0))
    }

    public var body: some View {
        NavigationStack {
            Form {
                Section("Edit Profile") {
                    TextField("Full Name", text: $name)
                    TextField("Designation / Role", text: $role)
                    TextField("Department", text: $department)
                    TextField("Monthly Salary (BDT)", text: $salary)
                        .keyboardType(.numberPad)
                }

                Section("Office Schedule Hours") {
                    DatePicker("Office In Time", selection: $officeInDate, displayedComponents: .hourAndMinute)
                    DatePicker("Office Out Time", selection: $officeOutDate, displayedComponents: .hourAndMinute)
                }

                Section("Status") {
                    Picker("Status", selection: $status) {
                        Text("Active").tag("Active")
                        Text("On Leave").tag("On Leave")
                        Text("Invited").tag("Invited")
                    }
                    .pickerStyle(.segmented)
                }

                Section {
                    Button("Save Changes") {
                        Task {
                            let sal = Double(salary) ?? employee.salary
                            let ok = await api.updateEmployee(
                                id: employee.id,
                                name: name,
                                role: role,
                                department: department,
                                salary: sal,
                                status: status,
                                officeInTime: hhmmString(from: officeInDate),
                                officeOutTime: hhmmString(from: officeOutDate)
                            )
                            if ok { onDone() }
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(BayshoreTheme.orange)
                }
            }
            .navigationTitle("Edit Employee")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") { onDone() }
                }
            }
        }
    }
}

