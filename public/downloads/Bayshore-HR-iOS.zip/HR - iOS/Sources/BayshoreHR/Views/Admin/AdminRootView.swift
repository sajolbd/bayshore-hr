import SwiftUI

public struct AdminRootView: View {
    public init() {}

    public var body: some View {
        TabView {
            AdminOverviewView()
                .tabItem {
                    Label("Overview", systemImage: "chart.bar.fill")
                }

            AdminStaffView()
                .tabItem {
                    Label("Staff", systemImage: "person.3.fill")
                }

            AdminDepartmentsView()
                .tabItem {
                    Label("Depts", systemImage: "building.2.fill")
                }

            AdminAttendanceView()
                .tabItem {
                    Label("Attendance", systemImage: "clock.fill")
                }

            AdminSettingsView()
                .tabItem {
                    Label("Settings", systemImage: "gearshape.fill")
                }
        }
        .tint(BayshoreTheme.orange)
    }
}

