import SwiftUI

@main
public struct BayshoreApp: App {
    @StateObject private var api = BayshoreApiClient.shared

    public init() {}

    public var body: some Scene {
        WindowGroup {
            Group {
                if api.isAuthenticated {
                    if api.currentUser?.isSuperAdmin == true || api.currentUser?.role == "Admin" {
                        AdminRootView()
                    } else {
                        EmployeeRootView()
                    }
                } else {
                    SignInView()
                }
            }
            .tint(BayshoreTheme.orange)
        }
    }
}

