import SwiftUI

public enum BayshoreTheme {
    public static let orange = Color(red: 234/255, green: 88/255, blue: 12/255)       // #EA580C
    public static let orangeDark = Color(red: 194/255, green: 65/255, blue: 12/255)   // #C2410C
    public static let orangeSoft = Color(red: 255/255, green: 247/255, blue: 237/255) // #FFF7ED
    
    public static let slate900 = Color(red: 15/255, green: 23/255, blue: 42/255)     // #0F172A
    public static let slate800 = Color(red: 30/255, green: 41/255, blue: 59/255)
    public static let slate700 = Color(red: 51/255, green: 65/255, blue: 85/255)
    public static let slate500 = Color(red: 100/255, green: 116/255, blue: 139/255)
    public static let slate200 = Color(red: 226/255, green: 232/255, blue: 240/255)
    public static let slate100 = Color(red: 241/255, green: 245/255, blue: 249/255)
    public static let slate50 = Color(red: 248/255, green: 250/255, blue: 252/255)
    
    public static let emerald600 = Color(red: 5/255, green: 150/255, blue: 105/255)
    public static let emerald50 = Color(red: 236/255, green: 253/255, blue: 245/255)
    
    public static let amber600 = Color(red: 217/255, green: 119/255, blue: 6/255)
    public static let amber50 = Color(red: 255/255, green: 251/255, blue: 235/255)
    
    public static let red600 = Color(red: 220/255, green: 38/255, blue: 38/255)
    public static let red50 = Color(red: 254/255, green: 242/255, blue: 242/255)
}

public struct CardModifier: ViewModifier {
    public func body(content: Content) -> some View {
        content
            .padding(14)
            .background(Color.white)
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .stroke(BayshoreTheme.slate200, lineWidth: 1)
            )
            .shadow(color: Color.black.opacity(0.02), radius: 4, x: 0, y: 2)
    }
}

public extension View {
    func bayshoreCard() -> some View {
        modifier(CardModifier())
    }
}

