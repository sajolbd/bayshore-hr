import Foundation
import CoreLocation

@MainActor
public final class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    public static let shared = LocationManager()

    @Published public var currentLocation: CLLocation?
    @Published public var authorizationStatus: CLAuthorizationStatus = .notDetermined
    @Published public var isInsideOffice: Bool = false
    @Published public var distanceFromHQMeters: Double = 0.0

    // Bayshore Communication Abtab Nagar HQ coordinates
    public static let hqLatitude: Double = 23.7656
    public static let hqLongitude: Double = 90.4378
    public static let geofenceRadiusMeters: Double = 200.0 // 200m office radius

    private let manager = CLLocationManager()

    override private init() {
        super.init()
        manager.delegate = self
        manager.desiredAccuracy = kCLLocationAccuracyBest
    }

    public func requestPermission() {
        manager.requestWhenInUseAuthorization()
    }

    public func startUpdating() {
        manager.startUpdatingLocation()
    }

    public func stopUpdating() {
        manager.stopUpdatingLocation()
    }

    public nonisolated func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        Task { @MainActor in
            self.authorizationStatus = manager.authorizationStatus
            if manager.authorizationStatus == .authorizedWhenInUse || manager.authorizationStatus == .authorizedAlways {
                manager.startUpdatingLocation()
            }
        }
    }

    public nonisolated func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let loc = locations.last else { return }
        Task { @MainActor in
            self.currentLocation = loc
            let hqLocation = CLLocation(latitude: Self.hqLatitude, longitude: Self.hqLongitude)
            let distance = loc.distance(from: hqLocation)
            self.distanceFromHQMeters = distance
            self.isInsideOffice = distance <= Self.geofenceRadiusMeters
        }
    }
}

