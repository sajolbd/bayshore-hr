import Foundation

public struct ExpenseClaim: Identifiable, Codable, Equatable {
    public let id: String
    public let employeeId: String
    public let employeeName: String
    public let category: String
    public let amount: Double
    public let description: String
    public let date: String
    public var status: String

    public init(
        id: String,
        employeeId: String,
        employeeName: String,
        category: String,
        amount: Double,
        description: String,
        date: String,
        status: String = "Pending"
    ) {
        self.id = id
        self.employeeId = employeeId
        self.employeeName = employeeName
        self.category = category
        self.amount = amount
        self.description = description
        self.date = date
        self.status = status
    }
}

