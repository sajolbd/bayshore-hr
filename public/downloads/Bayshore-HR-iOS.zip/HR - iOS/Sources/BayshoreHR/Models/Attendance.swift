import Foundation

public struct AttendanceRecord: Identifiable, Codable, Equatable {
    public let id: String
    public let employeeId: String
    public let employeeName: String
    public let employeeEmail: String
    public let avatar: String?
    public let department: String
    public let role: String
    public let checkIn: String
    public let checkOut: String?
    public let status: String
    public let workHours: String
    public let location: String
    public let date: String
    public let dateKey: String?
    public let geo: AttendanceGeo?
    public let scheduledInTime: String?
    public let scheduledOutTime: String?
    public let isLate: Bool?
    public let lateMinutes: Int?

    public init(
        id: String,
        employeeId: String,
        employeeName: String,
        employeeEmail: String,
        avatar: String? = nil,
        department: String = "Engineering",
        role: String = "Staff",
        checkIn: String,
        checkOut: String? = nil,
        status: String = "Present",
        workHours: String = "0h 0m",
        location: String = "Gulshan HQ, Dhaka",
        date: String = "",
        dateKey: String? = nil,
        geo: AttendanceGeo? = nil,
        scheduledInTime: String? = nil,
        scheduledOutTime: String? = nil,
        isLate: Bool? = nil,
        lateMinutes: Int? = nil
    ) {
        self.id = id
        self.employeeId = employeeId
        self.employeeName = employeeName
        self.employeeEmail = employeeEmail
        self.avatar = avatar
        self.department = department
        self.role = role
        self.checkIn = checkIn
        self.checkOut = checkOut
        self.status = status
        self.workHours = workHours
        self.location = location
        self.date = date
        self.dateKey = dateKey
        self.geo = geo
        self.scheduledInTime = scheduledInTime
        self.scheduledOutTime = scheduledOutTime
        self.isLate = isLate
        self.lateMinutes = lateMinutes
    }

    public var isLateCheckIn: Bool {
        if isLate == true { return true }
        return status.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() == "late"
    }
}

public func formatShiftTime12h(_ hhmm: String?, fallback: String = "09:00 AM") -> String {
    let raw = (hhmm ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
    if raw.isEmpty { return fallback }
    let upper = raw.uppercased()
    if upper.hasSuffix("AM") || upper.hasSuffix("PM") {
        return raw
    }
    let parts = raw.split(separator: ":")
    guard parts.count >= 2,
          let h24 = Int(parts[0]),
          let min = Int(parts[1].prefix(2)),
          (0...23).contains(h24),
          (0...59).contains(min) else {
        return fallback
    }
    let period = h24 >= 12 ? "PM" : "AM"
    let h12 = h24 % 12 == 0 ? 12 : h24 % 12
    return String(format: "%02d:%02d %@", h12, min, period)
}

public func hhmmString(from date: Date) -> String {
    let cal = Calendar.current
    let h = cal.component(.hour, from: date)
    let m = cal.component(.minute, from: date)
    return String(format: "%02d:%02d", h, m)
}

public func dateFromHHMM(_ hhmm: String, defaultHour: Int = 9, defaultMinute: Int = 0) -> Date {
    let parts = hhmm.split(separator: ":")
    let h = parts.count >= 2 ? (Int(parts[0]) ?? defaultHour) : defaultHour
    let m = parts.count >= 2 ? (Int(parts[1].prefix(2)) ?? defaultMinute) : defaultMinute
    var comps = Calendar.current.dateComponents([.year, .month, .day], from: Date())
    comps.hour = max(0, min(23, h))
    comps.minute = max(0, min(59, m))
    return Calendar.current.date(from: comps) ?? Date()
}

public func dhakaCurrentMonthKey() -> String {
    let fmt = DateFormatter()
    fmt.dateFormat = "yyyy-MM"
    fmt.timeZone = TimeZone(identifier: "Asia/Dhaka") ?? .current
    return fmt.string(from: Date())
}

public struct MonthlyReportEmployee: Codable, Equatable {
    public let id: String
    public let name: String
    public let department: String
    public let role: String

    public init(id: String, name: String, department: String, role: String) {
        self.id = id
        self.name = name
        self.department = department
        self.role = role
    }
}

public struct MonthlyReportRow: Identifiable, Codable, Equatable {
    public var id: String { dateKey }
    public let dateKey: String
    public let dayLabel: String
    public let scheduledIn12h: String
    public let scheduledOut12h: String
    public let checkInDisplay: String
    public let checkOutDisplay: String
    public let isLate: Bool
    public let lateMinutes: Int
    public let lateLabel: String
    public let workHours: String
    public let effectiveStatus: String
    public let location: String

    public init(
        dateKey: String,
        dayLabel: String,
        scheduledIn12h: String,
        scheduledOut12h: String,
        checkInDisplay: String,
        checkOutDisplay: String,
        isLate: Bool,
        lateMinutes: Int,
        lateLabel: String,
        workHours: String,
        effectiveStatus: String,
        location: String
    ) {
        self.dateKey = dateKey
        self.dayLabel = dayLabel
        self.scheduledIn12h = scheduledIn12h
        self.scheduledOut12h = scheduledOut12h
        self.checkInDisplay = checkInDisplay
        self.checkOutDisplay = checkOutDisplay
        self.isLate = isLate
        self.lateMinutes = lateMinutes
        self.lateLabel = lateLabel
        self.workHours = workHours
        self.effectiveStatus = effectiveStatus
        self.location = location
    }
}

public struct MonthlyReportSummary: Codable, Equatable {
    public let totalLoggedDays: Int
    public let presentDays: Int
    public let onTimeDays: Int
    public let lateDays: Int
    public let leaveDays: Int
    public let totalLateMinutes: Int
    public let totalLateFormatted: String
    public let totalWorkFormatted: String

    public init(
        totalLoggedDays: Int,
        presentDays: Int,
        onTimeDays: Int,
        lateDays: Int,
        leaveDays: Int,
        totalLateMinutes: Int,
        totalLateFormatted: String,
        totalWorkFormatted: String
    ) {
        self.totalLoggedDays = totalLoggedDays
        self.presentDays = presentDays
        self.onTimeDays = onTimeDays
        self.lateDays = lateDays
        self.leaveDays = leaveDays
        self.totalLateMinutes = totalLateMinutes
        self.totalLateFormatted = totalLateFormatted
        self.totalWorkFormatted = totalWorkFormatted
    }
}

public struct MonthlyAttendanceReport: Codable, Equatable {
    public let employee: MonthlyReportEmployee
    public let monthKey: String
    public let monthLabel: String
    public let officeIn12h: String
    public let officeOut12h: String
    public let rows: [MonthlyReportRow]
    public let summary: MonthlyReportSummary

    public init(
        employee: MonthlyReportEmployee,
        monthKey: String,
        monthLabel: String,
        officeIn12h: String,
        officeOut12h: String,
        rows: [MonthlyReportRow],
        summary: MonthlyReportSummary
    ) {
        self.employee = employee
        self.monthKey = monthKey
        self.monthLabel = monthLabel
        self.officeIn12h = officeIn12h
        self.officeOut12h = officeOut12h
        self.rows = rows
        self.summary = summary
    }
}

public struct AttendanceGeo: Codable, Equatable {
    public let latitude: Double?
    public let longitude: Double?
    public let accuracy: Double?
    public let address: String?
    public let geofenceStatus: String?
    public let distanceFromHQ: Double?
    public let checkInType: String?
    public let timestamp: String?

    public init(
        latitude: Double? = nil,
        longitude: Double? = nil,
        accuracy: Double? = nil,
        address: String? = nil,
        geofenceStatus: String? = nil,
        distanceFromHQ: Double? = nil,
        checkInType: String? = "Time Clock",
        timestamp: String? = nil
    ) {
        self.latitude = latitude
        self.longitude = longitude
        self.accuracy = accuracy
        self.address = address
        self.geofenceStatus = geofenceStatus
        self.distanceFromHQ = distanceFromHQ
        self.checkInType = checkInType
        self.timestamp = timestamp
    }
}

