import Foundation

public struct ServerHealth: Codable, Equatable {
    public let ok: Bool
    public let reachedServer: Bool
    public let mongodbUriConfigured: Bool
    public let jwtSecretConfigured: Bool
    public let databaseConnected: Bool
    public let databaseName: String?
    public let smtpConfigured: Bool
    public let smtpSource: String
    public let issueCode: String?
    public let issueMessage: String?

    public init(
        ok: Bool = false,
        reachedServer: Bool = false,
        mongodbUriConfigured: Bool = false,
        jwtSecretConfigured: Bool = false,
        databaseConnected: Bool = false,
        databaseName: String? = nil,
        smtpConfigured: Bool = false,
        smtpSource: String = "none",
        issueCode: String? = nil,
        issueMessage: String? = nil
    ) {
        self.ok = ok
        self.reachedServer = reachedServer
        self.mongodbUriConfigured = mongodbUriConfigured
        self.jwtSecretConfigured = jwtSecretConfigured
        self.databaseConnected = databaseConnected
        self.databaseName = databaseName
        self.smtpConfigured = smtpConfigured
        self.smtpSource = smtpSource
        self.issueCode = issueCode
        self.issueMessage = issueMessage
    }
}

