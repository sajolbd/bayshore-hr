import Foundation

public struct LeaveRequest: Identifiable, Codable, Equatable {
    public let id: String
    public let employeeId: String
    public let employeeName: String
    public let leaveType: String
    public let startDate: String
    public let endDate: String
    public let days: Int
    public let reason: String
    public var status: String

    public init(
        id: String,
        employeeId: String,
        employeeName: String,
        leaveType: String,
        startDate: String,
        endDate: String,
        days: Int,
        reason: String,
        status: String = "Pending"
    ) {
        self.id = id
        self.employeeId = employeeId
        self.employeeName = employeeName
        self.leaveType = leaveType
        self.startDate = startDate
        self.endDate = endDate
        self.days = days
        self.reason = reason
        self.status = status
    }
}

public struct Holiday: Identifiable, Codable, Equatable {
    public let id: String
    public let name: String
    public let date: String
    public let days: Int
    public let type: String

    public init(id: String, name: String, date: String, days: Int = 1, type: String = "Public") {
        self.id = id
        self.name = name
        self.date = date
        self.days = days
        self.type = type
    }
}

