import Foundation

public struct Department: Identifiable, Codable, Equatable {
    public let id: String
    public var name: String
    public var head: String
    public var headRole: String
    public var headAvatar: String?
    public var headcount: Int
    public var openPositions: Int
    public var budget: Double
    public var color: String

    public init(
        id: String,
        name: String,
        head: String,
        headRole: String = "Team Lead",
        headAvatar: String? = nil,
        headcount: Int = 0,
        openPositions: Int = 0,
        budget: Double = 0.0,
        color: String = "orange"
    ) {
        self.id = id
        self.name = name
        self.head = head
        self.headRole = headRole
        self.headAvatar = headAvatar
        self.headcount = headcount
        self.openPositions = openPositions
        self.budget = budget
        self.color = color
    }
}

