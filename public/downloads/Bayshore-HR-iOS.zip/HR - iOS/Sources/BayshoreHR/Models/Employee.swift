import Foundation

public struct EmployeeItem: Identifiable, Codable, Equatable {
    public let id: String
    public var name: String
    public var email: String
    public var role: String
    public var department: String
    public var status: String
    public var salary: Double
    public var avatar: String?
    public var phone: String
    public var location: String
    public var officeInTime: String
    public var officeOutTime: String

    public init(
        id: String,
        name: String,
        email: String,
        role: String,
        department: String,
        status: String = "Active",
        salary: Double = 60000.0,
        avatar: String? = nil,
        phone: String = "",
        location: String = "Abtab Nagar HQ, Dhaka",
        officeInTime: String = "09:00",
        officeOutTime: String = "18:00"
    ) {
        self.id = id
        self.name = name
        self.email = email
        self.role = role
        self.department = department
        self.status = status
        self.salary = salary
        self.avatar = avatar
        self.phone = phone
        self.location = location
        self.officeInTime = officeInTime
        self.officeOutTime = officeOutTime
    }
}

