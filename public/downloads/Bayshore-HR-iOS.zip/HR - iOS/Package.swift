// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "BayshoreHR",
    platforms: [
        .iOS(.v17)
    ],
    products: [
        .library(
            name: "BayshoreHR",
            targets: ["BayshoreHR"]
        ),
    ],
    dependencies: [],
    targets: [
        .target(
            name: "BayshoreHR",
            dependencies: [],
            path: "Sources/BayshoreHR",
            resources: [
                .process("../../Resources")
            ]
        ),
        .testTarget(
            name: "BayshoreHRTests",
            dependencies: ["BayshoreHR"],
            path: "Tests/BayshoreHRTests"
        )
    ]
)

