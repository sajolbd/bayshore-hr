# Bayshore HR — Native iOS Application

Native iOS client for the **Bayshore HR** system, built with **Swift 5.9+**, **SwiftUI**, **Combine**, and **CoreLocation**.

---

## 📱 Features

- **Authentication & Roles**:
  - Secure sign in with session cookie persistence.
  - Automatic role-based routing between **Employee Self-Service** and **Admin Suite**.
  - Diagnostics sheet with instant server switching between Vercel production (`https://bayshore-hr.vercel.app`) and local Wi-Fi development servers (`http://192.168.68.110:3000`).

- **Employee Self-Service**:
  - **Daily Time Clock**: One-tap Office Check-In / Clock Out verified against Abtab Nagar HQ geofence.
  - **Attendance Logs**: Defaults to **Today's** records with interactive date filter and date picker.
  - **100% Onsite Compliance**: Reflects Abtab Nagar HQ onsite policy.
  - **Profile Management**: Profile photo selection via `PhotosPicker`.
  - **Leave Management**: View leave quotas (Annual, Casual, Medical) and submit leave applications.

- **Admin Suite**:
  - **HR Overview**: Real-time staff count, attendance rate, pending leaves, and open positions.
  - **Staff Management**: Search directory, view status, Add new employees with automatic cartoon avatar generation (Dicebear Avataaars API), and Edit employee profiles.
  - **Departments Management**: Add, edit, and view department rosters with headcount, open hiring, and monthly budget.
  - **Team Attendance Monitor**: Live team punch log with date filtering.
  - **Settings & SMTP**: Outbound invitation email status and server health.

---

## 🛠️ Requirements & Tooling

- macOS Sonoma 14+ (or Sequoia 15+)
- Xcode 15.0+ (or Xcode 16+)
- iOS 17.0+ deployment target
- Swift 5.9+

---

## 🚀 How to Run in Xcode

1. Open Xcode on your Mac.
2. Select **File > Open...** and choose the `HR - iOS` directory (or drag `Package.swift` into Xcode).
3. Select an iOS Simulator (e.g., iPhone 15 Pro, iPhone 16) or a connected physical iOS device.
4. Press **Cmd + R** to build and run.
5. In the app's login screen, tap **Server & Diagnostics** to select **Vercel Prod** or your local Wi-Fi IP.

---

## 🏢 Geofence Office Coordinates
- **Latitude**: `23.7656`
- **Longitude**: `90.4378`
- **Radius**: `200 meters`
- **Office Location**: House - 21, Level 2, Road 1, Block A, Abtab Nagar, Dhaka 1212.

