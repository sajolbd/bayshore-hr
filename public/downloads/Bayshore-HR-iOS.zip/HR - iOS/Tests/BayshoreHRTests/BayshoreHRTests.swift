import XCTest
@testable import BayshoreHR

final class BayshoreHRTests: XCTestCase {
    func testAppInitializes() {
        XCTAssertNotNil(BayshoreApiClient.shared)
    }

    func testFormatShiftTime12hAndIsLateCheckIn() {
        XCTAssertEqual(formatShiftTime12h("09:00"), "09:00 AM")
        XCTAssertEqual(formatShiftTime12h("18:30"), "06:30 PM")
        XCTAssertEqual(formatShiftTime12h("", fallback: "09:00 AM"), "09:00 AM")

        let lateRecord = AttendanceRecord(
            id: "1",
            employeeId: "EMP-1",
            employeeName: "Test",
            employeeEmail: "t@bayshorecommunication.com",
            checkIn: "09:15 AM",
            status: "Late",
            isLate: true,
            lateMinutes: 15
        )
        XCTAssertTrue(lateRecord.isLateCheckIn)

        let onTimeRecord = AttendanceRecord(
            id: "2",
            employeeId: "EMP-2",
            employeeName: "On Time",
            employeeEmail: "o@bayshorecommunication.com",
            checkIn: "08:55 AM",
            status: "Present",
            isLate: false,
            lateMinutes: 0
        )
        XCTAssertFalse(onTimeRecord.isLateCheckIn)
    }

    func testMonthlyAttendanceReportDecoding() throws {
        let json = """
        {
          "employee": { "id": "EMP-1001", "name": "Ayesha", "department": "Engineering", "role": "Engineer" },
          "monthKey": "2026-11",
          "monthLabel": "November 2026",
          "officeIn12h": "09:00 AM",
          "officeOut12h": "06:00 PM",
          "rows": [
            {
              "dateKey": "2026-11-01",
              "dayLabel": "Sun",
              "scheduledIn12h": "09:00 AM",
              "scheduledOut12h": "06:00 PM",
              "checkInDisplay": "09:20 AM",
              "checkOutDisplay": "06:10 PM",
              "isLate": true,
              "lateMinutes": 20,
              "lateLabel": "20m Late",
              "workHours": "8h 50m",
              "effectiveStatus": "Late",
              "location": "Abtab Nagar HQ"
            }
          ],
          "summary": {
            "totalLoggedDays": 1,
            "presentDays": 1,
            "onTimeDays": 0,
            "lateDays": 1,
            "leaveDays": 0,
            "totalLateMinutes": 20,
            "totalLateFormatted": "20m",
            "totalWorkFormatted": "8h 50m"
          }
        }
        """.data(using: .utf8)!
        let decoded = try JSONDecoder().decode(MonthlyAttendanceReport.self, from: json)
        XCTAssertEqual(decoded.employee.id, "EMP-1001")
        XCTAssertEqual(decoded.rows.count, 1)
        XCTAssertTrue(decoded.rows[0].isLate)
        XCTAssertEqual(decoded.summary.lateDays, 1)
    }

    func testEmployeeAndAttendanceShiftHelpers() {
        let emp = EmployeeItem(
            id: "EMP-1",
            name: "Ayesha",
            email: "ayesha@bayshorecommunication.com",
            role: "Engineer",
            department: "Engineering",
            officeInTime: "10:00",
            officeOutTime: "19:00"
        )
        XCTAssertEqual(emp.officeInTime, "10:00")
        XCTAssertEqual(emp.officeOutTime, "19:00")
        XCTAssertEqual(formatShiftTime12h("10:00"), "10:00 AM")
        XCTAssertEqual(formatShiftTime12h("19:00"), "07:00 PM")

        let lateRec = AttendanceRecord(
            id: "att-1",
            employeeId: "EMP-1",
            employeeName: "Ayesha",
            employeeEmail: "ayesha@bayshorecommunication.com",
            checkIn: "10:20 AM",
            status: "Late",
            scheduledInTime: "10:00",
            scheduledOutTime: "19:00",
            isLate: true,
            lateMinutes: 20
        )
        XCTAssertTrue(lateRec.isLateCheckIn)
    }

    func testMonthlyReportDecodesFromEnvelopeJson() throws {
        let json = """
        {
          "report": {
            "employee": {
              "id": "EMP-1",
              "name": "Ayesha",
              "department": "Engineering",
              "role": "Engineer"
            },
            "monthKey": "2026-11",
            "monthLabel": "November 2026",
            "officeIn12h": "10:00 AM",
            "officeOut12h": "07:00 PM",
            "rows": [
              {
                "dateKey": "2026-11-01",
                "dayLabel": "Sun",
                "scheduledIn12h": "10:00 AM",
                "scheduledOut12h": "07:00 PM",
                "checkInDisplay": "10:20 AM",
                "checkOutDisplay": "07:05 PM",
                "isLate": true,
                "lateMinutes": 20,
                "lateLabel": "20m Late",
                "workHours": "8h 45m",
                "effectiveStatus": "Late",
                "location": "Abtab Nagar HQ"
              }
            ],
            "summary": {
              "totalLoggedDays": 1,
              "presentDays": 1,
              "onTimeDays": 0,
              "lateDays": 1,
              "leaveDays": 0,
              "totalLateMinutes": 20,
              "totalLateFormatted": "20m",
              "totalWorkFormatted": "8h 45m"
            }
          }
        }
        """.data(using: .utf8)!

        struct Envelope: Codable { let report: MonthlyAttendanceReport }
        let decoded = try JSONDecoder().decode(Envelope.self, from: json)
        XCTAssertEqual(decoded.report.employee.id, "EMP-1")
        XCTAssertEqual(decoded.report.rows.first?.isLate, true)
        XCTAssertEqual(decoded.report.summary.lateDays, 1)
    }
}
